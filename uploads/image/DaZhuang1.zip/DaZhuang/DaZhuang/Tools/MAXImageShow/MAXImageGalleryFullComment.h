//
//  MAXImageGalleryComment.h
//
//  Created by maxfong
//
//

#import "MAXImageGalleryFullScreen.h"

@protocol MAXImageGalleryFullCommentDelegate;
@interface MAXImageGalleryFullComment : MAXImageGalleryFullScreen
{
    UILabel *lblComment;//下面的label
}

@end

@protocol MAXImageGalleryFullCommentDelegate <NSObject>

- (void)imageGalleryCommentAfter:(UILabel *)lblComment_ currentPage:(NSUInteger)page;

@end