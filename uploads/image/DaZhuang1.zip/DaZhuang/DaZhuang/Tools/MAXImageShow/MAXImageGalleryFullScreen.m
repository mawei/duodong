//
//  MAXImageGalleryFullScreen.m
//
//  Created by maxfong on 13-8-17.
//
//

#import "MAXImageGalleryFullScreen.h"

#define kMAXALLOWCOUNT  10

@interface MAXImageGalleryFullScreen ()


@end

@implementation MAXImageGalleryFullScreen

- (void)loadView
{
    [super loadView];
    
    if (_bHiddenPage) {
        return;
    }
    
    if (self.totalCount <= kMAXALLOWCOUNT)
    {
        pageControl= [[UIPageControl alloc] initWithFrame:CGRectMake(0.0, CGRectGetHeight(imageGalleryFrame)-30, CGRectGetWidth(imageGalleryFrame), 30.0)];
        pageControl.autoresizesSubviews = YES;
        pageControl.clearsContextBeforeDrawing = YES;
        pageControl.clipsToBounds = NO;
        pageControl.backgroundColor = [UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:0.7];
        pageControl.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
        pageControl.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        pageControl.numberOfPages = self.totalCount;
        pageControl.enabled = NO;
        [pageControl setCurrentPage:self.currentPage];
        
        [self.view addSubview:pageControl];
    }
    else
    {
        lblPageInfo = [[UILabel alloc] initWithFrame:CGRectMake(0.0, CGRectGetHeight(imageGalleryFrame)-30, CGRectGetWidth(imageGalleryFrame), 30.0)];
        lblPageInfo.textAlignment = NSTextAlignmentCenter;
        lblPageInfo.textColor = [UIColor whiteColor];
        lblPageInfo.backgroundColor = [UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:0.7];
        lblPageInfo.text = [NSString stringWithFormat:@"%d/%d", (int)self.currentPage+1, (int)self.totalCount];
        
        [self.view addSubview:lblPageInfo];
    }
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.3;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = kCATransitionFade;
    [self.navigationController.view.layer addAnimation:transition forKey:nil];
}

- (void)setTopBar
{
    [super setTopBar];
    //导航栏隐藏
    self.navigationController.navigationBarHidden = YES;
    //任务栏隐藏
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
    //进度隐藏
//    [self performSelector:@selector(hiddenPageMessage:) withObject:@(YES) afterDelay:1];
}

- (void)didPressedImageView:(id)sender
{
    [[UIApplication sharedApplication] setStatusBarHidden:NO];
    self.navigationController.navigationBarHidden = NO;
    self.navigationController.navigationBar.translucent = NO;
    
    CATransition *transition = [CATransition animation];
    transition.duration = 0.3;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = kCATransitionFade;
    [self.navigationController.view.layer addAnimation:transition forKey:nil];
    
    [self.navigationController popViewControllerAnimated:NO];
}

- (void)setScrollViewDidScroll
{
//    [self hiddenPageMessage:NO];
    if (self.totalCount <= kMAXALLOWCOUNT)
    {
        [pageControl setCurrentPage:self.currentPage];
    }
    else
    {
        lblPageInfo.text = [NSString stringWithFormat:@"%d/%d", (int)(self.currentPage+1), (int)self.totalCount];
    }
}

- (void)setScrollViewDidEndDecelerating
{
//    [self performSelector:@selector(hiddenPageMessage:) withObject:@(YES) afterDelay:1];
}

- (void)hiddenPageMessage:(BOOL)hidden_
{
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
    if (hidden_)
    {
        @synchronized(self)
        {
            CATransition *transition = [CATransition animation];
            transition.duration = 0.2;
            transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
            transition.type = kCATransitionFade;
            [self.view.layer addAnimation:transition forKey:nil];
        }
    }
    if (self.totalCount <= kMAXALLOWCOUNT)
    {
        pageControl.hidden = hidden_;
    }
    else
    {
        lblPageInfo.hidden = hidden_;
    }
}
- (BOOL)prefersStatusBarHidden
{
    return YES;
}


@end
