//
//  MAXImageGalleryFullScreen.h

//
//  Created by maxfong
//
/*
    引用:
    #import "MAXImageGalleryFullScreen.h"
     
    引用:
    <MAXImageGalleryDelegate>
 
    //点击图片:
    - (void)didPreseedImageView:(id)sender
    {
        MAXImageGalleryFullScreen *imageGallery = [[MAXImageGalleryFullScreen alloc] initWithTotalCount:100 currentPage:0 delegate:self];
        [self.navigationController pushViewController:imageGallery animated:NO];
        [imageGallery release];
    }
     
    #pragma mark - MAXImageGalleryDelegate
    - (void)imageGalleryAfter:(UIImageView *)imgView currentPage:(NSUInteger)index
    {
        //...
        image = [UIImage imageWithContentsOfFile:imagePath];
        imgView.image = image;
    }
 */
//
//

#import "MAXImageGalleryCore.h"

@interface MAXImageGalleryFullScreen : MAXImageGalleryCore
{
    UIPageControl *pageControl;
    UILabel *lblPageInfo;
}

@property(nonatomic,assign)BOOL bHiddenPage;

- (void)setTopBar;
- (void)didPressedImageView:(id)sender;
- (void)setScrollViewDidScroll;
- (void)setScrollViewDidEndDecelerating;

@end
