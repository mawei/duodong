//
//  MAXImageGalleryCore.h
//
//  Created by maxfong
//
//  超类，子类定制UI
//
/*
 如果某些功能达不到，也可以使用KVO、适配器等扩展实现:
 如：页面需要实现图片的一些评价，完全可以在子类实现protocol并如MAXImageGalleryDelegate的方式一样，加载评论信息
 
 图片快速滑动，不加载图片，滑动停止再加载停止页的图片，其实很好实现，如有此需求，可以这样修改：
 在原本的scrollViewDidScroll实现的[self moveImageViewAndReset];中，不执行[delegate imageGalleryAfter:imageView currentPage:index];
 而在scrollViewDidEndDecelerating方法中实现类似[self loadDefaultData];的方法，循环加载3张图片;
 */
//
//

#import <UIKit/UIKit.h>

CGRect imageGalleryFrame;

@protocol MAXImageGalleryDelegate;
@interface MAXImageGalleryCore : UIViewController
<
UIScrollViewDelegate
>
{
    UIScrollView *scrollView_;
}

/**
 *	@brief	当前页
 */
@property (nonatomic, assign) NSInteger currentPage;
/**
 *	@brief	总数
 */
@property (nonatomic, assign) NSUInteger totalCount;

@property (nonatomic, retain, readonly) UIImageView *currentImageView;


/**
 *	@brief	初始化方法
 *
 *	@param 	totalCount_ 	总数
 *	@param 	currentPage_ 	当前页
 *	@param 	delegate_       delegate
 *
 *	@return	self
 */
- (id)initWithTotalCount:(NSUInteger)totalCount_
             currentPage:(NSUInteger)currentPage_
                delegate:(id<MAXImageGalleryDelegate>)delegate_;

//子类需重载以下方法
/**
 *	@brief	设置NavigationBar样式，以及页面增加新UI
 *
 *  如MAXImageGalleryFullScreen的pageControl或UIlabel，显示当前页信息
 *  MAXImageGalleryAddition内，导航栏增加左右按钮，分别实现返回、删除
 */
- (void)setTopBar;

/**
 *	@brief	点击图片的方法
 *
 *	@param 	sender 	imageView
 *
 *  如MAXImageGalleryFullScreen中，点击图片关闭页面
 *  MAXImageGalleryAddition内，点击图片隐藏导航栏、任务栏
 */
- (void)didPressedImageView:(id)sender;

/**
 *	@brief	滑动到某页触发的
 *
 *  如MAXImageGalleryFullScreen中，改变页码
 *  MAXImageGalleryAddition内，改变标题
 */
- (void)setScrollViewDidScroll;

/**
 *	@brief	滚动停止触发
 *
 *  如MAXImageGalleryFullScreen中，将Page信息延迟1s消失
 */
- (void)setScrollViewDidEndDecelerating;


@end

@protocol MAXImageGalleryDelegate <NSObject>

/**
 *	@brief	即将显示的图片，delegate
 *
 *	@param 	imgView 	返回的imageView
 *	@param 	page 	页码
 */
- (void)imageGalleryAfter:(UIImageView *)imgView currentPage:(NSUInteger)page;

@end