//
//  MAXImageGalleryCore.m
//
//  Created by maxfong on 13-8-17.
//
//

#import "MAXImageGalleryCore.h"
//#import "UIImageView+URLImage.h"

#define	kPHOTO_MAX_ZOOM_SCALE 3
#define kPHOTO_MIN_ZOOM_SCALE 1
#define kIMAGEWIDTH     CGRectGetWidth([[UIScreen mainScreen] bounds])
#define kIMAGEHEIGHT    CGRectGetHeight([[UIScreen mainScreen] bounds])
#define kIMAGEEDGE      40
#define kSCRIPTWIDTH    (CGRectGetWidth(imageGalleryFrame) + kIMAGEEDGE)
#define kIMAGEVIEWRECT(X)  CGRectMake((X) * kSCRIPTWIDTH, 0, CGRectGetWidth(imageGalleryFrame), CGRectGetHeight(imageGalleryFrame))

@interface MAXImageGalleryCore ()

@property (nonatomic, retain, readwrite) UIImageView *currentImageView;
@property (nonatomic, weak) id<MAXImageGalleryDelegate> delegate;
@property (nonatomic, strong) NSMutableDictionary *dicIdentife;
@property (nonatomic, assign) NSInteger iDirection;
@property (nonatomic, assign) BOOL bScrolled;

//放大扩展
@property (nonatomic) CGFloat touchX;
@property (nonatomic) CGFloat touchY;
@property (nonatomic) BOOL isTwiceTaping;
@property (nonatomic) BOOL isDoubleTapingForZoom;
@property (nonatomic) CGFloat currentScale;

@end

@implementation MAXImageGalleryCore
@synthesize delegate;
@synthesize currentPage;
@synthesize totalCount;
@synthesize dicIdentife;
@synthesize iDirection;
@synthesize bScrolled;

- (id)initWithTotalCount:(NSUInteger)totalCount_
             currentPage:(NSUInteger)currentPage_
                delegate:(id<MAXImageGalleryDelegate>)delegate_
{
    if (self = [self init]) {
        self.totalCount = totalCount_;
        self.currentPage = currentPage_;
        self.delegate = delegate_;
    }
    return self;
}

- (void)loadView
{
    [super loadView];
    
    extern CGRect imageGalleryFrame;
    if (CGRectIsEmpty(imageGalleryFrame)) imageGalleryFrame = [[UIScreen mainScreen] bounds];
    
    scrollView_ = [[UIScrollView alloc] initWithFrame:CGRectMake(CGRectGetMinX(imageGalleryFrame),
                                                                 CGRectGetMinY(imageGalleryFrame),
                                                                 kSCRIPTWIDTH,
                                                                 CGRectGetHeight(imageGalleryFrame))];
    scrollView_.contentSize = CGSizeMake((self.totalCount * kSCRIPTWIDTH)-kIMAGEEDGE, CGRectGetHeight(imageGalleryFrame));
    scrollView_.contentOffset = CGPointMake(kSCRIPTWIDTH * self.currentPage, 0);
    scrollView_.contentInset = UIEdgeInsetsMake(0, 0, 0, kIMAGEEDGE);
    scrollView_.delegate = self;
    scrollView_.alwaysBounceHorizontal = YES;
    scrollView_.alwaysBounceVertical = NO;
    scrollView_.autoresizesSubviews = YES;
    scrollView_.backgroundColor = [UIColor blackColor];
    scrollView_.bounces = YES;
    scrollView_.bouncesZoom = YES;
    scrollView_.canCancelContentTouches = YES;
    scrollView_.clearsContextBeforeDrawing = YES;
    scrollView_.clipsToBounds = YES;
    scrollView_.pagingEnabled = YES;
    scrollView_.scrollEnabled = YES;
    scrollView_.showsHorizontalScrollIndicator = NO;
    scrollView_.showsVerticalScrollIndicator = NO;
    [self.view addSubview:scrollView_];

    for (int i = 0 ; i < 3 ; i++)
    {
        int index = (int)self.currentPage + i - 1;
        //图片放大容器
        UIScrollView *scaleView = [[UIScrollView alloc] initWithFrame:kIMAGEVIEWRECT(index)];
        scaleView.tag = i + 101;
        scaleView.delegate = self;
        scaleView.bouncesZoom = YES;
        scaleView.bounces = NO;
        scaleView.showsVerticalScrollIndicator = YES;
        scaleView.showsHorizontalScrollIndicator = YES;
        scaleView.minimumZoomScale = kPHOTO_MIN_ZOOM_SCALE;
        scaleView.maximumZoomScale = kPHOTO_MAX_ZOOM_SCALE;
        scaleView.contentSize = CGSizeMake(CGRectGetWidth(imageGalleryFrame), CGRectGetHeight(imageGalleryFrame));
        scaleView.zoomScale = kPHOTO_MIN_ZOOM_SCALE;
        [scrollView_ addSubview:scaleView];
        
        //图片展示
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(imageGalleryFrame), CGRectGetHeight(imageGalleryFrame))];
        imageView.tag = i + 201;
        imageView.contentMode = UIViewContentModeScaleAspectFit;
        
        UITapGestureRecognizer *imageZoomGecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(didPressedImageView:)];
        [imageZoomGecognizer setNumberOfTapsRequired:1];
        [imageView addGestureRecognizer:imageZoomGecognizer];
        [imageView setUserInteractionEnabled:YES];
        
        //双击放大，缩小
        UITapGestureRecognizer *tapImgViewTwice = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(didPressedImageViewTwice:)];
        tapImgViewTwice.numberOfTapsRequired = 2;
        tapImgViewTwice.numberOfTouchesRequired = 1;
        [imageView addGestureRecognizer:tapImgViewTwice];
        [imageZoomGecognizer requireGestureRecognizerToFail:tapImgViewTwice];
        
        if (index >= 0
            && index < self.totalCount
            && [delegate respondsToSelector:@selector(imageGalleryAfter:currentPage:)])
        {
            [delegate imageGalleryAfter:imageView currentPage:index];
        }
        else imageView.image = nil;
        
        [scaleView addSubview:imageView];
        
        //少于3个，滑动不需要重用
        if (self.totalCount >= 3)
        {
            if (!self.dicIdentife) {
                dicIdentife = [[NSMutableDictionary alloc] initWithCapacity:3];
            }
            [self.dicIdentife setObject:@(i + 101) forKey:@((index + 3) % 3)];
        }
    }
    [self setTopBar];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
//    [AppDelegateEntity closeAllDragOperation];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
//    [UIImageView cancelURLOperationsForKey:self.delegate];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    [self loadDefaultData];
}

- (void)loadDefaultData
{
    [scrollView_.subviews enumerateObjectsUsingBlock:^(UIScrollView *scroll, NSUInteger index, BOOL *stop)
    {
        if ([scroll isKindOfClass:[UIScrollView class]])
        {
            UIImageView *imgView = (UIImageView *)[scroll viewWithTag:(scroll.tag+100)];
            if (imgView && [delegate respondsToSelector:@selector(imageGalleryAfter:currentPage:)])
            { 
                int respondIndex = (int)(self.currentPage + index - 1);
                if (respondIndex >= 0 && respondIndex < self.totalCount)
                {
                    [delegate imageGalleryAfter:imgView currentPage:respondIndex];
                }
                else imgView.image = nil;
            }
        }
    }];
}

-(void)dealloc
{
//    [UIImageView cancelURLOperationsForKey:self.delegate];
    self.dicIdentife = nil;
    self.delegate = nil;
}

#pragma mark - 子类需实现方法
- (void)setTopBar
{
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0)
    {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }
    else
    {
        [self setWantsFullScreenLayout:YES];
    }
   self.navigationController.navigationBar.translucent = YES;
    [self.navigationController.view setNeedsLayout];
//    [NSException raise:NSInternalInconsistencyException format:@"子类必须重载%@", NSStringFromSelector(_cmd)];
}
- (void)didPressedImageView:(id)sender
{
//    [NSException raise:NSInternalInconsistencyException format:@"子类必须重载%@", NSStringFromSelector(_cmd)];
}
- (void)setScrollViewDidScroll
{
//    [NSException raise:NSInternalInconsistencyException format:@"子类必须重载%@", NSStringFromSelector(_cmd)];
    
}
- (void)setScrollViewDidEndDecelerating
{
//    [NSException raise:NSInternalInconsistencyException format:@"子类必须重载%@", NSStringFromSelector(_cmd)];
}

- (void)didPressedImageViewTwice:(UIGestureRecognizer *)sender
{
    if(_isTwiceTaping){
        return;
    }
    _isTwiceTaping = YES;
    
    _touchX = [sender locationInView:sender.view].x;
    _touchY = [sender locationInView:sender.view].y;
    
    UIImageView *imageView = (UIImageView *)sender.view;
    UIScrollView *scaleView = (UIScrollView *)[imageView superview];
    
    if(_currentScale > kPHOTO_MIN_ZOOM_SCALE)
    {
        _currentScale = kPHOTO_MIN_ZOOM_SCALE;
        [scaleView setZoomScale:kPHOTO_MIN_ZOOM_SCALE animated:YES];
    }
    else
    {
        _isDoubleTapingForZoom = YES;
        _currentScale = kPHOTO_MAX_ZOOM_SCALE;
        [scaleView setZoomScale:kPHOTO_MAX_ZOOM_SCALE animated:YES];
    }
    _isDoubleTapingForZoom = NO;
    //延时做标记判断，使用户点击3次时的单击效果不生效
    [self performSelector:@selector(twiceTaping) withObject:nil afterDelay:0.6];
}

- (void)twiceTaping
{
    _isTwiceTaping = NO;
}

#pragma mark - 公共方法
//MoveNextTag
- (int)convertPage2Tag:(int)_index
{
    return [[self.dicIdentife objectForKey:@((_index+3) % 3)] intValue];
}

- (void)moveImageViewAndReset
{
    int index = (int)(self.iDirection + self.currentPage);
    if (index >= self.totalCount || index < 0) return;
    //获取TAG
    int tag = [self convertPage2Tag:index];
    UIScrollView *currentScroll = (UIScrollView *)[self.view viewWithTag:tag];
    //移动位置
    currentScroll.frame = kIMAGEVIEWRECT(index);
    currentScroll.contentSize = CGSizeMake(CGRectGetWidth(imageGalleryFrame), CGRectGetHeight(imageGalleryFrame));
    currentScroll.zoomScale = kPHOTO_MIN_ZOOM_SCALE;
    //通过scrollView找到ImageView
    UIImageView *imageView = (UIImageView *)[currentScroll viewWithTag:(tag+100)];
    //显示图片
    if ([delegate respondsToSelector:@selector(imageGalleryAfter:currentPage:)])
    {
        imageView.frame = CGRectMake(0, 0, CGRectGetWidth(imageGalleryFrame), CGRectGetHeight(imageGalleryFrame));
        [delegate imageGalleryAfter:imageView currentPage:index];
    }
    else imageView.image = nil;
}

- (UIImageView *)currentImageView
{
    int index = (int)(self.iDirection + self.currentPage);
    int tag = [self convertPage2Tag:index];
    
    UIScrollView *currentScroll = (UIScrollView *)[self.view viewWithTag:tag];
    return (UIImageView *)[currentScroll viewWithTag:(tag+100)];
}


#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (scrollView == scrollView_)
    {
        int scrollPage = floor((scrollView.contentOffset.x - kSCRIPTWIDTH / 2) / kSCRIPTWIDTH) + 1;
        if (self.totalCount < 3 && scrollPage < self.totalCount && scrollPage >= 0)
        {
            self.currentPage = scrollPage;
            [self setScrollViewDidScroll];
            return;
        }
        //防重复，必判断
        if ((scrollPage > self.currentPage && scrollPage < self.totalCount) || (scrollPage < self.currentPage && scrollPage >= 0))
        {
            self.iDirection = (scrollPage > self.currentPage) ? 1 : -1;
            self.currentPage = scrollPage;
            [self moveImageViewAndReset];
            [self setScrollViewDidScroll];
            bScrolled = YES;
        }
    }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView;
{
    if (scrollView == scrollView_)
    {
        [self setScrollViewDidEndDecelerating];
        //周边恢复初始状态
        if (bScrolled && self.currentPage >= 0 && self.currentPage < self.totalCount)
        {
            int index = (int)(self.currentPage + self.iDirection * 2);
            int tag = [self convertPage2Tag:index];
            UIScrollView *currentScroll = (UIScrollView *)[self.view viewWithTag:tag];
            currentScroll.contentSize = CGSizeMake(CGRectGetWidth(imageGalleryFrame), CGRectGetHeight(imageGalleryFrame));
            currentScroll.zoomScale = kPHOTO_MIN_ZOOM_SCALE;
            UIImageView *imageView = (UIImageView *)[currentScroll viewWithTag:(currentScroll.tag + 100)];
            imageView.frame = CGRectMake(0, 0, CGRectGetWidth(imageGalleryFrame), CGRectGetHeight(imageGalleryFrame));
            bScrolled = NO;
        }
    }
}

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    if (scrollView != scrollView_)
    {
        UIImageView *imageView = (UIImageView *)[scrollView viewWithTag:(scrollView.tag + 100)];
        //判断Count == 0，是因为未下载完成的图片不能放大
        //如果使用其他方式下载图片,请修改判断方式（下载中的图片有进度条，subviews.count > 0）
        if (imageView.subviews.count <= 1 && imageView.image) return imageView;
    }
    return nil;
}

- (void)scrollViewDidZoom:(UIScrollView *)scrollView
{
    if (scrollView != scrollView_)
    {
        UIImageView *imageView = (UIImageView *)[scrollView viewWithTag:(scrollView.tag + 100)];
        if (!imageView.image) return ;
        
        CGSize imageSize = imageView.image.size;
        CGFloat imageScale = fminf(CGRectGetWidth(imageView.frame)/imageSize.width, CGRectGetHeight(imageView.frame)/imageSize.height);
        CGSize scaledSize = CGSizeMake(imageSize.width*imageScale, imageSize.height*imageScale);
        
        scrollView.contentSize = CGSizeMake(MAX(scaledSize.width, CGRectGetWidth(imageGalleryFrame)), MAX(scaledSize.height, CGRectGetHeight(imageGalleryFrame)));
        
        CGFloat xcenter = scrollView.contentSize.width * 0.5, ycenter = scrollView.contentSize.height * 0.5;
        
        //双击放大时，精准坐标
        if(_isDoubleTapingForZoom)
        {
//            NSLog(@"x:%f y:%f", xcenter, ycenter);
            //精准坐标放大操作
            //max 待完成
//            xcenter = _touchX;
//            ycenter = _touchY;
//            NSLog(@"x:%f y:%f", xcenter, ycenter);
        }
        
        imageView.center = CGPointMake(xcenter, ycenter);
    }
}

- (void)scrollViewDidEndZooming:(UIScrollView *)scrollView withView:(UIView *)view atScale:(CGFloat)scale
{
    _currentScale = scale;
}
- (BOOL)prefersStatusBarHidden
{
    return YES;
}


@end
