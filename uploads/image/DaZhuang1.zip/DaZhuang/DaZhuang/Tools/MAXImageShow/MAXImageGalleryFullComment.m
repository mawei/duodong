//
//  MAXImageGalleryComment.m
//
//  Created by maxfong on 13-8-20.
//
//

#import "MAXImageGalleryFullComment.h"

@interface MAXImageGalleryFullComment ()

@property (nonatomic, assign) id commentDelegate;

@end

@implementation MAXImageGalleryFullComment
@synthesize commentDelegate;

- (void)loadView
{
    [super loadView];
    lblComment = [[UILabel alloc] initWithFrame:CGRectMake(0, CGRectGetHeight(imageGalleryFrame)-60, CGRectGetWidth(imageGalleryFrame), 30)];
    lblComment.adjustsFontSizeToFitWidth = YES;
    lblComment.clearsContextBeforeDrawing = YES;
    lblComment.lineBreakMode = NSLineBreakByTruncatingTail;
    lblComment.minimumScaleFactor = 10.0;
    lblComment.numberOfLines = 1;
    lblComment.textColor = [UIColor whiteColor];
    lblComment.font = [UIFont systemFontOfSize:13.0f];
    lblComment.backgroundColor = [UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:0.7];
   
    [self.view addSubview:lblComment];
    
    if ([commentDelegate respondsToSelector:@selector(imageGalleryCommentAfter:currentPage:)])
    {
        [commentDelegate imageGalleryCommentAfter:lblComment currentPage:self.currentPage];
    }
    
   
}

- (id)initWithTotalCount:(NSUInteger)totalCount_
             currentPage:(NSUInteger)currentPage_
                delegate:(id<MAXImageGalleryDelegate>)delegate_
{
    self = [super initWithTotalCount:totalCount_
                  currentPage:currentPage_
                     delegate:delegate_];
    self.commentDelegate = delegate_;
    return self;
}

- (void)setScrollViewDidScroll
{
    [super setScrollViewDidScroll];
    if ([commentDelegate respondsToSelector:@selector(imageGalleryCommentAfter:currentPage:)])
    {
        [commentDelegate imageGalleryCommentAfter:lblComment currentPage:self.currentPage];
    }
}
@end
