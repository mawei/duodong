//
//  DZStatusManage.h
//  DaZhuang
//
//  Created by Mac020 on 15/2/28.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MBProgressHUD.h"
#import "AppDelegate.h"
#define iOS7                                ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0) //&& ([[[UIDevice currentDevice] systemVersion] floatValue] < 8.0))
#define AppDelegateEntity                   ((AppDelegate *)[UIApplication sharedApplication].delegate)

@interface DZStatusManage : NSObject

@property (nonatomic, copy)NSString *roleTitle;//角色类型

@property (nonatomic, copy) NSString *roleMobile;//角色手机号码

@property (nonatomic, copy) NSString *roleUid;//角色UID

@property (nonatomic, copy) NSString *roleName;//角色昵称

@property (nonatomic, copy) NSString *roleMessage;//角色信息

+ (DZStatusManage *)shareManage;
+ (CGFloat)getLabelHeight:(NSString *)content labelWidth:(CGFloat)contentW;
@end
