//
//  AppDelegate.m
//  DaZhuang
//
//  Created by Mac020 on 15/2/25.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import "AppDelegate.h"
#import "DZTabBarController.h"
#import "DZSelectRoleViewController.h"
#import "DZStatusManage.h"
#import "DZSendLawyerImageViewController.h"
#import <SMS_SDK/SMS_SDK.h>
#define appKey @"602aa82d943e"
#define appSecret @"42f83bcc258adee2230bf64c605a4cc0"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {

    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    if ([[[DZStatusManage shareManage] roleUid] isEqualToString:@"还没登陆"]) {
        
        [SMS_SDK registerApp:appKey
                  withSecret:appSecret];
        [self selectRoleViewController];
    }else
        [self showMainController];
    [self setPublicState];
    [self.window makeKeyAndVisible];

    // Override point for customization after application launch.
    return YES;
}
- (void)setPublicState
{
    [[UINavigationBar appearance] setBackgroundImage:[self drawImage] forBarPosition:UIBarPositionTopAttached barMetrics:UIBarMetricsDefault];
//    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    [[UINavigationBar appearance] setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor whiteColor],NSFontAttributeName:[UIFont systemFontOfSize:18.f]}];
    [[UINavigationBar appearance] setTintColor:[UIColor whiteColor]];
//    UIImage* image = [UIImage imageNamed:@"arrow_back"];
//   
//    [[UIBarButtonItem appearance] setBackgroundImage:[image resizableImageWithCapInsets:UIEdgeInsetsMake(0, image.size.width, 0, 0)] forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
//
//    [[UIBarButtonItem appearance] setBackButtonTitlePositionAdjustment:UIOffsetMake(-400.f, 0) forBarMetrics:UIBarMetricsDefault];
  
  
}
- (UIImage *)drawImage
{
    CGSize imageSize = CGSizeMake(self.window.bounds.size.width, 64);
    UIGraphicsBeginImageContextWithOptions(imageSize, 0, [UIScreen mainScreen].scale);
    [[UIColor colorWithRed:25.f/255.f green:85.f/255.f blue:158.f/255.f alpha:1.0] set];
    UIRectFill(CGRectMake(0, 0, imageSize.width, imageSize.height));
    UIImage *pressedColorImg = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return pressedColorImg;
}

- (void)showMainController
{
 if ([[[DZStatusManage shareManage] roleMessage] isEqualToString:@"还没审核通过"] && [[[DZStatusManage shareManage] roleTitle] isEqualToString:@"律师"])
 {
     DZSendLawyerImageViewController *sendImagesViewController = [[DZSendLawyerImageViewController alloc] initWithNibName:@"DZSendLawyerImageViewController" bundle:nil];
     self.window.rootViewController = sendImagesViewController;
     
 }else
 {
     DZTabBarController *tabBar = [[DZTabBarController alloc] init];
    self.window.rootViewController = tabBar;
 }
}

- (void)selectRoleViewController
{
      DZSelectRoleViewController *selectRole = [[DZSelectRoleViewController alloc] initWithNibName:@"DZSelectRoleViewController" bundle:nil];
      self.window.rootViewController = selectRole;
    
}
- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
