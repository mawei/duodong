//
//  DZShareNetApiClient.h
//  DaZhuang
//
//  Created by Mac020 on 15/3/2.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import "DZStatusManage.h"
#import "AFHTTPSessionManager.h"

@interface DZShareNetApiClient : AFHTTPSessionManager

+ (instancetype)sharedClient;
@end
