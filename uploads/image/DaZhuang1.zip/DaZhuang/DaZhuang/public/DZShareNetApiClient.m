//
//  DZShareNetApiClient.m
//  DaZhuang
//
//  Created by Mac020 on 15/3/2.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import "DZShareNetApiClient.h"

@implementation DZShareNetApiClient

+ (instancetype)sharedClient{
    
    DZShareNetApiClient *sharedClient = [[DZShareNetApiClient alloc] initWithBaseURL:[NSURL URLWithString:@"http://112.124.15.38/dazhuang_web/"]];
     [sharedClient.reachabilityManager startMonitoring];
    return sharedClient;
}
@end
