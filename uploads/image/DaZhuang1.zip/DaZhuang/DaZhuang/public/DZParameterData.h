//
//  DZParameterData.h
//  DaZhuang
//
//  Created by jason on 15/3/11.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DZParameterData : NSObject
@property (nonatomic, copy)NSString *user_id;//注册用户id
@property (nonatomic, copy)NSString *case_id;//案件id
@property (nonatomic, copy)NSString *lawyer_id;//律师id
@property (nonatomic, copy)NSString *quotation_id;//报价id
@property (nonatomic, copy)NSString *compensation;//保底收益
@property (nonatomic, copy)NSString *expense;//律师费
@property (nonatomic, copy)NSString *create_time;//报价时间
@property (nonatomic, copy)NSString *time;//事故时间
@property (nonatomic, copy)NSString *address;//事故地点
@property (nonatomic, copy)NSString *hurt;//人生伤害
@property (nonatomic, copy)NSString *info;//故事详情
@property (nonatomic, copy)NSString *status;//案件状态
@property (nonatomic, copy)NSString *content;//消息详情


@end
