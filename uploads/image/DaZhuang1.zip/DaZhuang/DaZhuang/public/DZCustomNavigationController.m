//
//  DZCustomNavigationController.m
//  DaZhuang
//
//  Created by Mac020 on 15/3/5.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import "DZCustomNavigationController.h"
//通常意义上的动画时间
#define DZTransitionConstant_TransitionDuration 0.25f

//左VC移动的长度和其整个宽度的比例
#define DZTransitionConstant_LeftVC_Move_Ratio_Of_Width 0.29f

//阴影相关
#define DZTransitionConstant_RightVC_ShadowOffset_Width (-0.4f)
#define DZTransitionConstant_RightVC_ShadowRadius 3.0f
#define DZTransitionConstant_RightVC_ShadowOpacity 0.3f


//有效的向右拖动的最小速率，即为大于这个速率就认为想返回上一页罢了
#define DZTransitionConstant_Valid_MIN_Velocity 300.0f

typedef enum {
    DZTransitionAnimationTypePush, //push
    DZTransitionAnimationTypePop, //pop
} DZTransitionAnimationType;


@interface DZUIViewControllerAnimation: NSObject<UIViewControllerAnimatedTransitioning>
@property (nonatomic, assign) DZTransitionAnimationType type;

@end


@implementation DZUIViewControllerAnimation

- (void)animateTransition:(id<UIViewControllerContextTransitioning>)transitionContext
{
    UIViewController *fromVC = [transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey];
    UIViewController *toVC = [transitionContext viewControllerForKey:UITransitionContextToViewControllerKey];
    //可以理解为是动画进行中的view容器,当前fromVC.view已经在容器里了,但是toVC.view没有
    UIView *containerView = [transitionContext containerView];
    fromVC.view.layer.shadowColor = [UIColor blackColor].CGColor;
    fromVC.view.layer.shadowOffset = CGSizeMake(DZTransitionConstant_RightVC_ShadowOffset_Width,0);
    fromVC.view.layer.shadowRadius = DZTransitionConstant_RightVC_ShadowRadius;
    fromVC.view.layer.shadowOpacity = DZTransitionConstant_RightVC_ShadowOpacity;
    //放进容器
    [containerView insertSubview:toVC.view belowSubview:fromVC.view];
    //设置初始值
    toVC.view.transform = CGAffineTransformMakeTranslation(-toVC.view.frame.size.width*DZTransitionConstant_LeftVC_Move_Ratio_Of_Width, 0);
    [UIView animateWithDuration:[self transitionDuration:transitionContext] delay:0.0f options:UIViewAnimationOptionCurveLinear animations:^{
            fromVC.view.transform = CGAffineTransformMakeTranslation(fromVC.view.frame.size.width, 0);
     
        toVC.view.transform = CGAffineTransformIdentity;
        
    } completion:^(BOOL finished) {
        fromVC.view.layer.shadowOpacity = 0.0f;
        
        [transitionContext completeTransition:!transitionContext.transitionWasCancelled];
        
        
        fromVC.view.transform = CGAffineTransformIdentity; //重置回来,两个都重置是因为动画可能会被取消
        toVC.view.transform = CGAffineTransformIdentity;
    }];


}
- (NSTimeInterval)transitionDuration:(id<UIViewControllerContextTransitioning>)transitionContext {
    //设置一个动画时间。
   
    return DZTransitionConstant_TransitionDuration;
}
@end
@interface DZCustomNavigationController ()<UINavigationControllerDelegate,UIGestureRecognizerDelegate>


@property (nonatomic, strong) UIPercentDrivenInteractiveTransition *percentDrivenInteractivePopTransition;
@property (nonatomic, strong) DZUIViewControllerAnimation *animationController;
@end

@implementation DZCustomNavigationController



- (void)viewDidLoad {
    [super viewDidLoad];
    __weak typeof (self) weakSelf = self;
    if ([self respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        self.interactivePopGestureRecognizer.delegate = weakSelf;
    }
//    UIScreenEdgePanGestureRecognizer *gestureRecognizer = [[UIScreenEdgePanGestureRecognizer alloc] initWithTarget:self action:@selector(__DZransition_HandlePopRecognizer:)];
//     ((UIScreenEdgePanGestureRecognizer*)gestureRecognizer).edges = UIRectEdgeLeft;
//    [self.view addGestureRecognizer:gestureRecognizer];
    self.delegate = self;
       // Do any additional setup after loading the view.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated
{

    if (self.viewControllers.count == 0) {
        
    }else
    {
        if ([self respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
            self.interactivePopGestureRecognizer.enabled = NO;
        }

    UIImage* image = [UIImage imageNamed:@"arrow_back"];
    UIButton *btnBack = [UIButton buttonWithType:UIButtonTypeCustom];
    btnBack.frame = CGRectMake(0, 0, self.navigationBar.bounds.size.height, self.navigationBar.bounds.size.height);
    [btnBack setImage:image forState:UIControlStateNormal];
        btnBack.contentEdgeInsets = UIEdgeInsetsMake(0, -10, 0, 10);
    [btnBack addTarget:self action:@selector(popToLastView) forControlEvents:UIControlEventTouchUpInside];
        
    UIBarButtonItem *leftBarButton =  [[UIBarButtonItem alloc] initWithCustomView:btnBack];

        
        viewController.navigationItem.leftBarButtonItem = leftBarButton;
    }
    [super pushViewController:viewController animated:animated];

}

- (void)navigationController:(UINavigationController *)navigationController
       didShowViewController:(UIViewController *)viewController
                    animated:(BOOL)animated
{
    if (self.viewControllers.count == 1)
        return;
        
    
    if ([navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        navigationController.interactivePopGestureRecognizer.enabled = YES;
    }
}

//- (id<UIViewControllerAnimatedTransitioning>)navigationController:(UINavigationController *)navigationController
//                                  animationControllerForOperation:(UINavigationControllerOperation)operation
//                                               fromViewController:(UIViewController *)fromVC
//                                                 toViewController:(UIViewController *)toVC {
//    
//   if(operation == UINavigationControllerOperationPop)
//   {
//       if (!_animationController) {
//           _animationController = [[DZUIViewControllerAnimation alloc]init];
//       }
//       _animationController.type = DZTransitionAnimationTypePop;
//       return _animationController;
//   }
//    return nil;
//    
//}
//
//- (id<UIViewControllerInteractiveTransitioning>)navigationController:(UINavigationController *)navigationController
//                         interactionControllerForAnimationController:(id<UIViewControllerAnimatedTransitioning>)animationController {
//   
//    
//    if ([animationController isKindOfClass:[DZUIViewControllerAnimation class]]&&((DZUIViewControllerAnimation*)animationController).type==DZTransitionAnimationTypePop) {
//        return self.percentDrivenInteractivePopTransition;
//    }
//    
//    return nil;
//}

- (void)popToLastView
{
    [self popViewControllerAnimated:YES];
}

- (void)__DZransition_HandlePopRecognizer:(UIPanGestureRecognizer*)recognizer {
    if (recognizer.state == UIGestureRecognizerStateBegan) {
        //建立一个transition的百分比控制对象
        self.percentDrivenInteractivePopTransition = [[UIPercentDrivenInteractiveTransition alloc] init];
        self.percentDrivenInteractivePopTransition.completionCurve = UIViewAnimationCurveLinear;
        
        [self popViewControllerAnimated:YES];
        return;
    }
    if (!self.percentDrivenInteractivePopTransition) {
        return;
    }
    CGFloat progress = [recognizer translationInView:self.view].x / (self.view.bounds.size.width * 1.0f);
    progress = MIN(1.0, MAX(0.0, progress));
    
    if (recognizer.state == UIGestureRecognizerStateChanged) {
        //根据拖动调整transition状态
        [self.percentDrivenInteractivePopTransition updateInteractiveTransition:progress];
    }else if ((recognizer.state == UIGestureRecognizerStateEnded || recognizer.state == UIGestureRecognizerStateCancelled)) {
        //结束或者取消了手势，根据方向和速率来判断应该完成transition还是取消transition
        CGFloat velocity = [recognizer velocityInView:self.view].x; //我们只关心x的速率
        
        if (velocity > DZTransitionConstant_Valid_MIN_Velocity) { //向右速率太快就完成
            self.percentDrivenInteractivePopTransition.completionSpeed /= 1.3f;
            [self.percentDrivenInteractivePopTransition finishInteractiveTransition];
        }else if (velocity < -DZTransitionConstant_Valid_MIN_Velocity){ //向左速率太快就取消
            self.percentDrivenInteractivePopTransition.completionSpeed /= 1.8f;
            [self.percentDrivenInteractivePopTransition cancelInteractiveTransition];
        }else{
            BOOL isFinished = NO;
            if (progress > 0.8f || (progress>=0.2f&&velocity>0.0f)) {
                isFinished = YES;
            }
            if (isFinished) {
                self.percentDrivenInteractivePopTransition.completionSpeed /= 1.5f;
                [self.percentDrivenInteractivePopTransition finishInteractiveTransition];
            }else{
                self.percentDrivenInteractivePopTransition.completionSpeed /= 2.0f;
                [self.percentDrivenInteractivePopTransition cancelInteractiveTransition];
            }
        }
        self.percentDrivenInteractivePopTransition = nil;
    }

    
}
-(UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
