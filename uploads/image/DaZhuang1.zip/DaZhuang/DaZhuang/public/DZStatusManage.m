//
//  DZStatusManage.m
//  DaZhuang
//
//  Created by Mac020 on 15/2/28.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import "DZStatusManage.h"

@implementation DZStatusManage
@synthesize roleUid = _roleUid;
@synthesize roleTitle = _roleTitle;

+ (CGFloat)getLabelHeight:(NSString *)content labelWidth:(CGFloat)contentW
{
    // 宽度W
    // label的字体 HelveticaNeue  Courier
    UIFont *fnt = [UIFont fontWithName:@"HelveticaNeue" size:14.0f];
    // iOS7中用以下方法替代过时的iOS6中的sizeWithFont:constrainedToSize:lineBreakMode:方法
    CGRect tmpRect = [content boundingRectWithSize:CGSizeMake(contentW, 0) options:NSStringDrawingUsesLineFragmentOrigin attributes:[NSDictionary dictionaryWithObjectsAndKeys:fnt,NSFontAttributeName, nil] context:nil];
    
    // 高度H
    CGFloat contentH = tmpRect.size.height;
    return contentH;
}
+ (DZStatusManage *)shareManage
{
    static DZStatusManage *manage = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
            manage = [[[self class] alloc]init];
    });
    return manage;
    
}

- (void)setRoleTitle:(NSString *)roleTitle
{
    [[NSUserDefaults standardUserDefaults] setObject:roleTitle forKey:@"DZ_roleTitle"];
    [[NSUserDefaults standardUserDefaults]  synchronize];

}
- (NSString *)roleTitle
{
    NSString *roleTitle = [[NSUserDefaults standardUserDefaults] objectForKey:@"DZ_roleTitle"];
    if (!roleTitle) {
        roleTitle = @"还没登陆";
    }
    return roleTitle;

}
- (void)setRoleUid:(NSString *)roleUid
{
    [[NSUserDefaults standardUserDefaults] setObject:roleUid forKey:@"DZ_roleUid"];
    [[NSUserDefaults standardUserDefaults]  synchronize];
}
- (NSString *)roleUid
{
    NSString *roleUid = [[NSUserDefaults standardUserDefaults] objectForKey:@"DZ_roleUid"];
    if (!roleUid) {
        roleUid = @"还没登陆";
    }
        return roleUid;
}


- (void)setRoleMessage:(NSString *)roleMessage
{
    [[NSUserDefaults standardUserDefaults] setObject:roleMessage forKey:@"DZ_roleMessage"];
    [[NSUserDefaults standardUserDefaults]  synchronize];
}

- (NSString *)roleMessage
{
    NSString *roleMessage = [[NSUserDefaults standardUserDefaults] objectForKey:@"DZ_roleMessage"];
    if (!roleMessage) {
        roleMessage = @"还没审核通过";
    }
    return roleMessage;

}

- (void)setRoleName:(NSString *)roleName
{
    [[NSUserDefaults standardUserDefaults] setObject:roleName forKey:@"DZ_roleName"];
    [[NSUserDefaults standardUserDefaults]  synchronize];
    
}

- (NSString *)roleName
{
    NSString *roleName = [[NSUserDefaults standardUserDefaults] objectForKey:@"DZ_roleName"];
    if (!roleName) {
        roleName = @"还没有昵称";
    }
    return roleName;
 
}


- (void)setRoleMobile:(NSString *)roleMobile
{
    [[NSUserDefaults standardUserDefaults] setObject:roleMobile forKey:@"DZ_roleMobile"];
    [[NSUserDefaults standardUserDefaults]  synchronize];

}

- (NSString *)roleMobile
{
    NSString *roleMobile = [[NSUserDefaults standardUserDefaults] objectForKey:@"DZ_roleMobile"];
    if (!roleMobile) {
        roleMobile = @"还没有注册";
    }
    return roleMobile;

}
@end
