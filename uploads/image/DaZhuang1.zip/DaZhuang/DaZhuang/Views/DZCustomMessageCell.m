//
//  DZCustomMessageCell.m
//  DaZhuang
//
//  Created by jason on 15/3/21.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import "DZCustomMessageCell.h"

@implementation DZCustomMessageCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (void)setParameterData:(DZParameterData *)parameterData
{
    _parameterData = parameterData;
    
    _lbMessage.text = _parameterData.content;
    _lbTime.text = _parameterData.create_time;
    
}
@end
