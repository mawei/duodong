//
//  DZCustomLawyerPriceCell.m
//  DaZhuang
//
//  Created by Mac020 on 15/3/9.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import "DZCustomLawyerPriceCell.h"

@implementation DZCustomLawyerPriceCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
