//
//  DZCustomPayementCell.m
//  DaZhuang
//
//  Created by jason on 15/3/21.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import "DZCustomPayementCell.h"

@implementation DZCustomPayementCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (void)setParameterData:(DZParameterData *)parameterData
{
    _parameterData = parameterData;
    _lbTime.text = parameterData.create_time;
    _lbMoney.text = parameterData.expense;
    _lbStatus.text = parameterData.status;
    _lbCase.text = @"保密";
}
@end
