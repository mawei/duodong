//
//  DZCustomPayementCell.h
//  DaZhuang
//
//  Created by jason on 15/3/21.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DZParameterData.h"

@interface DZCustomPayementCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *lbCase;

@property (weak, nonatomic) IBOutlet UILabel *lbTime;
@property (weak, nonatomic) IBOutlet UILabel *lbMoney;
@property (weak, nonatomic) IBOutlet UILabel *lbStatus;
@property (nonatomic, strong)DZParameterData *parameterData;

@end
