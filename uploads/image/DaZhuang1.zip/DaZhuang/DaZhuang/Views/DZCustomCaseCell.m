//
//  DZCustomCaseCell.m
//  DaZhuang
//
//  Created by Mac020 on 15/3/5.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import "DZCustomCaseCell.h"

@implementation DZCustomCaseCell

- (void)awakeFromNib {
    // Initialization code
}
- (void)setParameterData:(DZParameterData *)parameterData
{
    _parameterData = parameterData;
    _lbHurt.text = parameterData.hurt;
    _lbTime.text = parameterData.time;
    _lbAddress.text = parameterData.address;
    _lbInfo.text = parameterData.info;
    _lbState.text = parameterData.status;
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
