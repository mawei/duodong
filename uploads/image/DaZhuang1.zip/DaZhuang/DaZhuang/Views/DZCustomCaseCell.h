//
//  DZCustomCaseCell.h
//  DaZhuang
//
//  Created by Mac020 on 15/3/5.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DZParameterData.h"
@interface DZCustomCaseCell : UITableViewCell
@property (nonatomic, strong)DZParameterData *parameterData;
@property (strong, nonatomic) IBOutlet UILabel *lbHurt;
@property (strong, nonatomic) IBOutlet UILabel *lbTime;
@property (strong, nonatomic) IBOutlet UILabel *lbAddress;
@property (strong, nonatomic) IBOutlet UILabel *lbInfo;
@property (strong, nonatomic) IBOutlet UILabel *lbState;

@end
