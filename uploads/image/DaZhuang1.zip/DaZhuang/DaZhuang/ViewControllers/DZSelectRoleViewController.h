//
//  DZSelectRoleViewController.h
//  DaZhuang
//
//  Created by Mac020 on 15/2/25.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DZSelectRoleViewController : UIViewController
- (IBAction)selectRole:(UIButton *)sender;

@end
