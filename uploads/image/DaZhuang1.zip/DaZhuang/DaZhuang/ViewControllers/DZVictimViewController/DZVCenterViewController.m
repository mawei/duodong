//
//  DZVCenterViewController.m
//  DaZhuang
//
//  Created by Mac020 on 15/2/25.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import "DZVCenterViewController.h"
#import "DZVMyCaseListViewController.h"
#import "DZEditMyInfoViewController.h"
#import "DZStatusManage.h"
#import "DZMessageViewController.h"
@interface DZVCenterViewController ()<UITableViewDataSource , UITableViewDelegate>

@end

@implementation DZVCenterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self loadBaseView];
    [self loadBaseData];

    // Do any additional setup after loading the view from its nib.
}

- (void)viewWillLayoutSubviews
{
    
}

- (void)loadBaseView
{
    self.navigationItem.title = @"我的";
    self.myTableView.tableHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _myTableView.frame.size.width, 20.f)];
    _lbRole.text = [DZStatusManage shareManage].roleTitle;
    _lbRoleMobile.text = [DZStatusManage shareManage].roleMobile;
}

- (void)loadBaseData
{
    
    
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return 0.f;
    }else if(section == 1){
        return 20.f;
    }
    return 0.f;
        
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        return 80.f;
    }else if(indexPath.section == 1){
        return 50.f;
    }return 0.f;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        return 1;
    }else if(section == 1){
        return 2;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section == 0){
        
        return _myUserCell;
    }else if (indexPath.section == 1){
        
        switch (indexPath.row) {
            case 0:
                return _myCaseCell;
                break;
            case 1:
                return _myNotificationCell;
                break;
            default:
                break;
        }
    }
    return nil;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section == 0)
    {
        DZEditMyInfoViewController *editViewController = [[DZEditMyInfoViewController alloc]initWithNibName:@"DZEditMyInfoViewController" bundle:nil];
        editViewController.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:editViewController animated:YES];
        
    }
    else if(indexPath.section == 1)
    {
        switch (indexPath.row) {
            case 0:{
                DZVMyCaseListViewController *myCaseList = [[DZVMyCaseListViewController alloc] initWithNibName:@"DZVMyCaseListViewController" bundle:nil];
                 myCaseList.hidesBottomBarWhenPushed = YES;
                [self.navigationController pushViewController:myCaseList animated:YES];
            }
                break;
            case 1:{
                DZMessageViewController *myMessage = [[DZMessageViewController alloc] initWithNibName:@"DZMessageViewController" bundle:nil];
                myMessage.title = @"我的通知";
                myMessage.hidesBottomBarWhenPushed = YES;
                [self.navigationController pushViewController:myMessage animated:YES];
            }
                
                break;
            default:
                break;
        }
    }
    return ;
    
}
- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [_myTableView deselectRowAtIndexPath:[_myTableView indexPathForSelectedRow] animated:YES];


}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docspath = [paths objectAtIndex:0];
    NSString *headName = [docspath stringByAppendingPathComponent:@"headImage.jpg"];
    NSFileManager *fileMgr = [NSFileManager defaultManager];
    if ([fileMgr fileExistsAtPath:headName]) {
        _imgHead.image = nil;
        _imgHead.image = [UIImage imageWithContentsOfFile:headName];
    }
    _lbName.text = [DZStatusManage shareManage].roleName;

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
