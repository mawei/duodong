//
//  DZVMyCaseListViewController.m
//  DaZhuang
//
//  Created by Mac020 on 15/3/5.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import "DZVMyCaseListViewController.h"
#import "DZCustomCaseCell.h"
#import "DZVLawyerPriceListViewController.h"
#import "DZShareNetApiClient.h"
#import "MJRefresh.h"
#import "DZParameterData.h"
@interface DZVMyCaseListViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    MBProgressHUD *HUD;

}
@property (nonatomic, strong)NSMutableArray *dataArray;
@property (nonatomic, assign)NSUInteger page;
@end

@implementation DZVMyCaseListViewController

- (void)dealloc
{
    [_dataArray removeAllObjects];
    self.dataArray = nil;
    HUD = nil;
    [_myTableView removeFooter];
    [_myTableView removeHeader];
    
    
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self loadBaseView];
    [self loadBaseData];

    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillLayoutSubviews
{
    
}
- (void)loadBaseData
{
    _dataArray = [[NSMutableArray alloc] init];
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
    HUD.removeFromSuperViewOnHide = YES;

    [self.navigationController.view addSubview:HUD];
    [HUD show:YES];
    [self loadData:1];
}


- (void)loadData:(NSUInteger)page
{
    _page = page;
    
    DZShareNetApiClient *shareNetApiClient = [DZShareNetApiClient sharedClient];

    NSString *currentPage = [NSString stringWithFormat:@"%lu",(unsigned long)page];
  
    NSString *URLString = nil;
    NSMutableDictionary *parameter = [NSMutableDictionary dictionary];
    [parameter setObject:[DZStatusManage shareManage].roleUid forKey:@"user_id"];
    [parameter setObject:currentPage forKey:@"page"];
    [parameter setObject:@"10" forKey:@"number"];

    if ([[DZStatusManage shareManage].roleTitle isEqualToString:@"律师"]) {
        URLString = [NSString stringWithFormat:@"index.php?/api/get_cases_by_lawyer?"];
       [parameter setObject:self.title forKey:@"status"];
    }else if ([[DZStatusManage shareManage].roleTitle isEqualToString:@"受害人"])
    {
    URLString = [NSString stringWithFormat:@"index.php?/api/get_cases_by_victim?"];
    }
    URLString = [URLString stringByAddingPercentEscapesUsingEncoding: NSUTF8StringEncoding];
    
    [shareNetApiClient GET:URLString parameters:parameter success:^(NSURLSessionDataTask *task, id JSON) {
        [shareNetApiClient.reachabilityManager stopMonitoring];
               NSArray *jsonArray =[JSON objectForKey:@"data"];
        
        if ([[JSON objectForKey:@"code"] integerValue] == 0) {
            
            if (page == 1) {
                [_dataArray removeAllObjects];
            }

            for (NSUInteger i = 0; i <jsonArray.count ; i ++) {
                NSDictionary *dic = [jsonArray objectAtIndex:i];
                DZParameterData *parameterData = [[DZParameterData alloc]init];
                parameterData.time = [dic objectForKey:@"time"];
                parameterData.address = [dic objectForKey:@"address"];
                parameterData.hurt = [dic objectForKey:@"hurt"];
                parameterData.info = [dic objectForKey:@"info"];
                parameterData.status = [dic objectForKey:@"status"];
                [_dataArray addObject:parameterData];
            }
            if (page == 1) {
                [self.myTableView headerEndRefreshing];
            }else
                [self.myTableView footerEndRefreshing];

            if (jsonArray.count > 0) {

                _page ++ ;
                [_myTableView reloadData];
                [self.myTableView setFooterHidden:NO];
  
            }else
            {
                [_myTableView reloadData];
                [self.myTableView setFooterHidden:YES];
            }

            [self showHUD:nil];
        }else
            [self showHUD:@"加载失败"];
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        
        
        if ([shareNetApiClient.reachabilityManager isReachable])
        {
            [self showHUD:@"网络无连接"];
        }else
            [self showHUD:@"加载失败"];
        
        [shareNetApiClient.reachabilityManager stopMonitoring];
        if (page == 1) {
            [self.myTableView headerEndRefreshing];
        }else
            [self.myTableView footerEndRefreshing];

    }];

    
}
- (void)showHUD:(NSString *)message
{
    if (HUD) {
        [HUD hide:YES];
        HUD = nil;
    }
    if (!message) {
        return;
    }
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.navigationController.view animated:YES];
    
    // Configure for text only and offset down
    hud.mode = MBProgressHUDModeText;
    hud.labelText = message;
    hud.margin = 10.f;
    hud.removeFromSuperViewOnHide = YES;
    
    [hud hide:YES afterDelay:3];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}
- (void)loadBaseView
{

    self.navigationItem.title = @"我的案件";
     UINib *cellNib = [UINib nibWithNibName:@"DZCustomCaseCell" bundle:nil];
    [self.myTableView registerNib:cellNib forCellReuseIdentifier:@"DZCustomCaseCell"];
    self.myTableView.tableHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _myTableView.frame.size.width, .1f)];
    [self setupRefresh];
    
}

- (void)setupRefresh
{
    // 1.下拉刷新(进入刷新状态就会调用self的headerRereshing)
    [self.myTableView addHeaderWithTarget:self action:@selector(headerRereshing)];
    
    // 2.上拉加载更多(进入刷新状态就会调用self的footerRereshing)
    [self.myTableView addFooterWithTarget:self action:@selector(footerRereshing)];
    
    // 设置文字(也可以不设置,默认的文字在MJRefreshConst中修改)
    self.myTableView.headerPullToRefreshText = @"下拉可以刷新了";
    self.myTableView.headerReleaseToRefreshText = @"松开马上刷新了";
    self.myTableView.headerRefreshingText = @"正在帮你刷新中,不客气";
    
    self.myTableView.footerPullToRefreshText = @"上拉可以加载更多数据了";
    self.myTableView.footerReleaseToRefreshText = @"松开马上加载更多数据了";
    self.myTableView.footerRefreshingText = @"正在帮你加载中,不客气";

}


- (void)headerRereshing
{
    [self loadData:1];
}
- (void)footerRereshing
{
    [self loadData:_page];
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return _dataArray.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    DZParameterData *parameterData = [_dataArray objectAtIndex:indexPath.section];
    CGRect r = [ UIScreen mainScreen ].bounds;

    CGFloat width = MIN(r.size.width, r.size.height);
    return 107.f + [DZStatusManage getLabelHeight:parameterData.info labelWidth:width - 16.f];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    DZCustomCaseCell *cell = (DZCustomCaseCell *)[tableView dequeueReusableCellWithIdentifier:@"DZCustomCaseCell"];
    DZParameterData *parameterData = [_dataArray objectAtIndex:indexPath.section];
    cell.parameterData = parameterData;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
   
//    DZVLawyerPriceListViewController *myCaseContent = [[DZVLawyerPriceListViewController alloc] initWithNibName:@"DZVLawyerPriceListViewController" bundle:nil];
//    [self.navigationController pushViewController:myCaseContent animated:YES];
    
}


- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [_myTableView deselectRowAtIndexPath:[_myTableView indexPathForSelectedRow] animated:YES];
}
-(UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


@end
