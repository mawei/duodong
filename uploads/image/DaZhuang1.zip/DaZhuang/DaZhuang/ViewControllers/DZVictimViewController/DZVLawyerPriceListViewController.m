//
//  DZVLawyerPriceListViewController.m
//  DaZhuang
//
//  Created by Mac020 on 15/3/5.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import "DZVLawyerPriceListViewController.h"
#import "DZCustomLawyerPriceCell.h"
#import "DZLawyerContentViewController.h"
@interface DZVLawyerPriceListViewController ()

@end

@implementation DZVLawyerPriceListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self loadBaseView];
    [self loadBaseData];
    // Do any additional setup after loading the view from its nib.
}
- (void)loadBaseView
{
    self.navigationItem.title = @"律师报价";
    UINib *cellNib = [UINib nibWithNibName:@"DZCustomLawyerPriceCell" bundle:nil];
    [self.myTableView registerNib:cellNib forCellReuseIdentifier:@"DZCustomLawyerPriceCell"];
    self.myTableView.tableHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _myTableView.frame.size.width, .1f)];
    
}

- (void)loadBaseData
{
    
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 70.f;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 5;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    DZCustomLawyerPriceCell *cell = (DZCustomLawyerPriceCell *)[tableView dequeueReusableCellWithIdentifier:@"DZCustomLawyerPriceCell"];
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    DZLawyerContentViewController *lawyerContentViewController = [[DZLawyerContentViewController alloc] initWithNibName:@"DZLawyerContentViewController" bundle:nil];
    [self.navigationController pushViewController:lawyerContentViewController animated:YES];

    
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [_myTableView deselectRowAtIndexPath:[_myTableView indexPathForSelectedRow] animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
