//
//  DZVSendImageViewController.h
//  DaZhuang
//
//  Created by jason on 15/3/11.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DZVSendImageViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITableView *myTableView;
@property (strong, nonatomic) IBOutlet UITableViewCell *amountCell;
@property (strong, nonatomic) IBOutlet UITableViewCell *imgsCell;
@property (weak, nonatomic) IBOutlet UITextField *fdAmount;
@property (weak, nonatomic) IBOutlet UIButton *btnAddImage;
- (IBAction)addImages:(id)sender;
- (IBAction)fdAmountChage:(UITextField *)sender;

@end
