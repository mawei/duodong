//
//  DZVPutCaseViewController.m
//  DaZhuang
//
//  Created by Mac020 on 15/2/25.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import "DZVPutCaseViewController.h"
#import "DZVSendImageViewController.h"
@interface DZVPutCaseViewController ()

@end

@implementation DZVPutCaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self loadBaseView];
    [self loadBaseData];
    // Do any additional setup after loading the view from its nib.
}

- (void)loadBaseView
{
    self.navigationItem.title = @"案件上传";
    
}

- (void)loadBaseData
{
    NSString *content = @"1.不是人的不能进还有是人的也不能进,上传图片要赛选,态度要认真图片内容要真实.\n\n2.我就不说了都让你们说了我还能说什么呢,总之好之为之哈哈哈哈😊\n\n3.😢死你妹啊O(∩_∩)O~啦啦啦啦\n\n4.一个人的日子里我还在干什么.";
    _lbContent.text = content;
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
-(UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (IBAction)selectImage:(UIButton *)sender {
    
    DZVSendImageViewController *sendViewController = [[DZVSendImageViewController alloc] initWithNibName:@"DZVSendImageViewController" bundle:nil];
    sendViewController.hidesBottomBarWhenPushed = YES;
    
    [self.navigationController pushViewController:sendViewController animated:YES];
    
    
}
@end
