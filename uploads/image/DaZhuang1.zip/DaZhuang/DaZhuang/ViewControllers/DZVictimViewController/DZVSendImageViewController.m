//
//  DZVSendImageViewController.m
//  DaZhuang
//
//  Created by jason on 15/3/11.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import "DZVSendImageViewController.h"
#import "ZYQAssetPickerController.h"
#import "MAXImageGalleryFullComment.h"
#import "DZStatusManage.h"
#import "ZipArchive.h"
#import "DZShareNetApiClient.h"

@interface DZVSendImageViewController ()<UIScrollViewDelegate,UIActionSheetDelegate,MAXImageGalleryDelegate,ZYQAssetPickerControllerDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
    MBProgressHUD *HUD;

}
@property (nonatomic, strong)NSMutableArray *indexPathsForSelectedItems;
@property (nonatomic, strong)NSMutableArray *imagesArray;
@property (nonatomic, strong)NSMutableArray *bigImagesArray;
@end

@implementation DZVSendImageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self loadBaseView];
    [self loadBaseData];

    // Do any additional setup after loading the view from its nib.
}
- (void)loadBaseView
{
    self.navigationItem.title = @"上传内容";
    self.myTableView.tableHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _myTableView.frame.size.width, 20.f)];
    self.navigationItem.rightBarButtonItem =
    [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"发送", nil)
                                     style:UIBarButtonItemStylePlain
                                    target:self
                                    action:@selector(finishPickingAssets:)];
    self.navigationItem.rightBarButtonItem.enabled = NO;
    
}

- (void)finishPickingAssets:(id)sender
{
    [_indexPathsForSelectedItems removeAllObjects];
    [_bigImagesArray removeAllObjects];
    _fdAmount.text = nil;
    [self reloadCell];

    [_fdAmount resignFirstResponder];
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    HUD.removeFromSuperViewOnHide = YES;
    HUD.labelText = @"正在上传";
    [self.view addSubview:HUD];
    [HUD show:YES];

    NSFileManager *fileMgr = [NSFileManager defaultManager];

    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docspath = [paths objectAtIndex:0];
    NSString *zipFile = [docspath stringByAppendingPathComponent:@"casePicture.zip"];
    ZipArchive *za = [[ZipArchive alloc] init];
    [za CreateZipFile2:zipFile];

   [_bigImagesArray enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
      
       NSString *name = [NSString stringWithFormat:@"caseImage%lu.jpg",(unsigned long)idx];
       NSString *imagePath = [docspath stringByAppendingPathComponent:name];
       NSData *imageData = (NSData *)obj;
       [imageData writeToFile:imagePath atomically:YES];
       [za addFileToZip:imagePath newname:name];
       NSError *err;
       [fileMgr removeItemAtPath:imagePath error:&err];
   }];
    BOOL success = [za CloseZipFile2];
    if (success) {
        [self startSendZip:zipFile];
    }else
        [self showHUD:@"上传失败"];
}

- (void)startSendZip:(NSString *)filePath
{
    NSURL *url = [NSURL fileURLWithPath:filePath];
    
    DZShareNetApiClient *shareNetApiClient = [DZShareNetApiClient sharedClient];
    
    NSString *URLString = [NSString stringWithFormat:@"index.php?/api/create_case"];
    NSDictionary *parameters = [NSDictionary dictionaryWithObjectsAndKeys:[DZStatusManage shareManage].roleUid,@"user_id",@"6",@"image_number",_fdAmount.text,@"fdAmount", nil];
    URLString = [URLString stringByAddingPercentEscapesUsingEncoding: NSUTF8StringEncoding];
    [shareNetApiClient POST:URLString parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        NSError *error;
        [formData appendPartWithFileURL:url name:@"casePicture.zip" error:&error];
        
    } success:^(NSURLSessionDataTask *task, id responseObject) {
    
        [shareNetApiClient.reachabilityManager stopMonitoring];
        [self showHUD:@"上传成功"];
        [_indexPathsForSelectedItems removeAllObjects];
        [_bigImagesArray removeAllObjects];
        _fdAmount.text = nil;
        [self reloadCell];
    
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        [shareNetApiClient.reachabilityManager stopMonitoring];
        
        NSLog(@"%@",error);
        if ([shareNetApiClient.reachabilityManager isReachable])
        {
            [self showHUD:@"连接服务器失败"];
        }else
            [self showHUD:@"上传失败"];
        
    }];

}
- (void)showHUD:(NSString *)message
{
    if (HUD) {
        [HUD hide:YES];
        HUD = nil;
    }
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    // Configure for text only and offset down
    hud.mode = MBProgressHUDModeText;
    hud.labelText = message;
    hud.margin = 10.f;
    hud.removeFromSuperViewOnHide = YES;
    
    [hud hide:YES afterDelay:3];
}


- (void)loadBaseData
{
    
    _indexPathsForSelectedItems = [[NSMutableArray alloc] init];
    _imagesArray = [[NSMutableArray alloc] init];
    _bigImagesArray = [[NSMutableArray alloc] init];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0 && indexPath.row == 0) {
        return _amountCell.frame.size.height;
    }else if(indexPath.section == 1 && indexPath.row == 0){
        
        CGFloat width = MIN([UIScreen mainScreen].bounds.size.width,[UIScreen mainScreen].bounds.size.height) -10;
        
        CGFloat height = width/4.f;
        NSUInteger count = _indexPathsForSelectedItems.count + 1;
        if (count > 4) {
            NSUInteger number = count/4;
            height =number * height + 0.1*height;
            
            if (count%4 > 0) {
                height += width/4.f;
            }
   
        }
          else
              height = height * 1.1f;
        NSLog(@"%f",height);

        return height;
    }else
        return 0.f;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section == 0){
        
        return _amountCell;
    }else if (indexPath.section == 1){
        CGFloat height = (_imgsCell.frame.size.width - 10)/4.f;

      __block  NSUInteger number = _indexPathsForSelectedItems.count %4;
      __block  NSUInteger count = _indexPathsForSelectedItems.count /4;
        _btnAddImage.frame = CGRectMake(0.05*height + number *height + 5.f, count*height + 0.1 *height , height*0.9f, height*0.9f);
          [_indexPathsForSelectedItems enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
              ALAsset *asset = (ALAsset *)obj;
              
              number = idx %4;
              count = idx /4;
              
        
              UIImageView *imageView = [[UIImageView alloc] initWithFrame: CGRectMake(0.05*height + number *height + 5.f, count*height + 0.1 *height , height*0.9f, height*0.9f)];
              imageView.userInteractionEnabled = YES;
              UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(fangDa:)];
              [imageView addGestureRecognizer:tap];
              imageView.image =[UIImage imageWithCGImage:asset.thumbnail];
              imageView.tag = idx;
              
              [_imgsCell.contentView addSubview:imageView];
            [_imagesArray addObject:imageView];
              
          }];
        return _imgsCell;
    }
    return nil;
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    [_fdAmount resignFirstResponder];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)addImages:(id)sender {
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"打开照相机",@"从手机相册获取", nil];
    
    [actionSheet showInView:self.view];

    
}

- (IBAction)fdAmountChage:(UITextField *)sender {
    
    [self refreshFlied];

}
#pragma UIActionSheetDelegate

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex) {
        case 0:
            [self takePhoto];
            break;
        case 1:
            [self LocalPhoto];
            break;
        default:
            break;
    }
}

/*
 
 开始照相
 */
- (void)takePhoto
{
    if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera])
    {
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.delegate = self;
        //设置拍照后的图片可被编辑
        picker.allowsEditing = YES;
        picker.sourceType = UIImagePickerControllerSourceTypeCamera;
        [self presentViewController:picker animated:YES completion:nil];
    }else
    {
        NSLog(@"模拟其中无法打开照相机,请在真机中使用");
    }
 
}
/*
 打开本地相册
 */

- (void)LocalPhoto
{
    ZYQAssetPickerController *picker = [[ZYQAssetPickerController alloc] init];
    picker.maximumNumberOfSelection = 20;
    picker.assetsFilter = [ALAssetsFilter allPhotos];
    picker.showEmptyGroups=NO;
    picker.isFinishDismissViewController = YES;
    picker.indexPathsForSelectedItems = _indexPathsForSelectedItems;
    picker.pickDelegate=self;
    picker.selectionFilter = [NSPredicate predicateWithBlock:^BOOL(id evaluatedObject, NSDictionary *bindings) {
        if ([[(ALAsset*)evaluatedObject valueForProperty:ALAssetPropertyType] isEqual:ALAssetTypeVideo]) {
            return NO;
        } else {
            return YES;
        }
    }];
    
    [self.navigationController presentViewController:picker animated:YES completion:NULL];
  
}

- (void)reloadCell
{
    for (UIImageView *imageView in _imagesArray) {
        [imageView removeFromSuperview];
    }
    [_imagesArray removeAllObjects];
    NSIndexPath *indexPath=[NSIndexPath indexPathForRow:0 inSection:1];
    [_myTableView reloadRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath,nil] withRowAnimation:UITableViewRowAnimationNone];
    [self refreshFlied];
    
}

-(void)refreshFlied
{
    if (_fdAmount.text.length > 0 && _imagesArray.count > 0) {
        
        self.navigationItem.rightBarButtonItem.enabled = YES;
        
    }else
        self.navigationItem.rightBarButtonItem.enabled = NO;


    
}

#pragma mark - ZYQAssetPickerController Delegate
-(void)assetPickerController:(UIViewController *)picker didFinishPickingAssets:(NSArray *)assets{
//    [picker dismissViewControllerAnimated:YES completion:nil];
//
//    return;
    [_bigImagesArray removeAllObjects];
    
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:picker.view animated:YES];
        
        // Configure for text only and offset down
        hud.labelText = @"开始处理";
        hud.margin = 10.f;
        hud.removeFromSuperViewOnHide = YES;
        hud.mode = MBProgressHUDModeIndeterminate;
        [hud show:YES];
    dispatch_queue_t newThread = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_async(newThread,^{
        
        [_indexPathsForSelectedItems enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
            ALAsset *asset = (ALAsset *)obj;
            UIImage *image = [UIImage imageWithCGImage:asset.defaultRepresentation.fullScreenImage];
            
            NSData *imageData = UIImageJPEGRepresentation(image, 1.f);
            if (imageData.length > 500 * 1024) {
                imageData =  UIImageJPEGRepresentation(image, 0.5);
                
            }
            [_bigImagesArray addObject:imageData];
            
        }];
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [hud hide:YES];
            [self reloadCell];
            [picker dismissViewControllerAnimated:YES completion:nil];

        });

    });
    
    
    
    
    
    
    
}




#pragma mark - UIImagePickerControllerDelegate

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    NSLog(@"您取消了选择图片");
    [picker dismissViewControllerAnimated:YES completion:nil];
}
- (void)imagePickerController:(UIImagePickerController*)picker didFinishPickingMediaWithInfo:(NSDictionary*)info
{
    UIImage *imageToSave;
    // Handle a still image capture
    imageToSave = (UIImage*)[info objectForKey:UIImagePickerControllerOriginalImage];
    
   
    
    ALAssetsLibrary * assetLibrary = [ZYQAssetGroupViewController  defaultAssetsLibrary];
    
    [assetLibrary writeImageToSavedPhotosAlbum:imageToSave.CGImage orientation:(ALAssetOrientation)imageToSave.imageOrientation completionBlock:^(NSURL *assetURL, NSError *error) {
        if (!error) {
          [assetLibrary assetForURL:assetURL resultBlock:^(ALAsset *asset) {
            
            [_indexPathsForSelectedItems addObject:asset];
              [self  assetPickerController:picker didFinishPickingAssets:nil];
            
            //camer
            
        } failureBlock:^(NSError *error) {
            [self reloadCell];

            [picker dismissViewControllerAnimated:YES completion:^{
                
            }];
            
            //camer
            
        }];
        }
else
{
    [self reloadCell];
    [picker dismissViewControllerAnimated:YES completion:^{
        
    }];
}
    }];
   
    
    //    imageViewPreview.image=imageToSave;
    //    self.imgSingleSelect=imageToSave;
    
    
}
#pragma mark - 大图浏览
- (void)fangDa:(UIGestureRecognizer *)gestureRecognizer{
    
   
    MAXImageGalleryFullComment *imageShow = [[MAXImageGalleryFullComment alloc] initWithTotalCount:_indexPathsForSelectedItems.count currentPage:gestureRecognizer.view.tag delegate:self];
//    UIButton *chane = [UIButton buttonWithType:UIButtonTypeCustom];
//    UIImage *checkedIcon = [UIImage imageWithContentsOfFile:[[[NSBundle mainBundle] resourcePath]
//                                                             stringByAppendingPathComponent:
//    [NSString stringWithFormat:@"ZYQAssetPicker.Bundle/Images/%@@2x.png",(!iOS7) ? @"AssetsPickerChecked~iOS6" : @"AssetsPickerChecked"]]];
//    [chane setBackgroundImage:checkedIcon forState:UIControlStateNormal];
//    [chane setBackgroundImage:[UIImage imageWithContentsOfFile:[[[NSBundle mainBundle] resourcePath]
//                                                               stringByAppendingPathComponent:
//                                                               [NSString stringWithFormat:@"ZYQAssetPicker.Bundle/Images/%@@2x.png",@"No"]]] forState:UIControlStateSelected];
//    CGFloat widht = MIN([[UIScreen mainScreen] bounds].size.width, [[UIScreen mainScreen] bounds].size.height);
//    chane.frame = CGRectMake(widht - checkedIcon.size.width -20, 20, checkedIcon.size.width, checkedIcon.size.height);
//    [chane addTarget:self action:@selector(selectAdd:) forControlEvents:UIControlEventTouchUpInside];
//    [self.navigationController.view addSubview:chane];
    
    [self.navigationController pushViewController:imageShow animated:NO];
}
- (void)imageGalleryAfter:(UIImageView *)imgView currentPage:(NSUInteger)page{
    NSData *imageData = (NSData *)[_bigImagesArray objectAtIndex:page];
    
    imgView.image = nil;
    imgView.image = [UIImage imageWithData:imageData];
    
    
}

//- (void)selectAdd:(UIButton *)btn
//{
//    if (btn.selected) {
//        btn.selected = NO;
//    }else
//        btn.selected = YES;
//}
- (void)dealloc
{
    [_bigImagesArray removeAllObjects];
    self.bigImagesArray = nil;
    [_indexPathsForSelectedItems removeAllObjects];
    self.indexPathsForSelectedItems = nil;
    [_imagesArray makeObjectsPerformSelector:@selector(removeFromSuperview)];

    self.imagesArray = nil;
}
@end
