//
//  DZLawyerContentViewController.m
//  DaZhuang
//
//  Created by jason on 15/3/11.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import "DZLawyerContentViewController.h"
#import "DZShareNetApiClient.h"
#import "DZParameterData.h"
@interface DZLawyerContentViewController ()
{
    MBProgressHUD *HUD;

}

@end

@implementation DZLawyerContentViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self loadBaseView];
    [self loadBaseData];

    // Do any additional setup after loading the view from its nib.
}

- (void)viewWillAppear:(BOOL)animated
{

    [super viewWillAppear:animated];


}
- (void)loadBaseView
{
    self.navigationItem.title = @"律师详情";
    self.myTableView.tableHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _myTableView.frame.size.width, .1f)];
    CGFloat height;
    CGFloat width;
    height = MAX([UIScreen mainScreen].bounds.size.height,  [UIScreen mainScreen].bounds.size.width);
    width = MIN([UIScreen mainScreen].bounds.size.width,  [UIScreen mainScreen].bounds.size.height);
    _footTableView.frame = CGRectMake(0, 0,width, height - self.navigationController.navigationBar.bounds.size.height - 20.f - 230.f);
    self.myTableView.tableFooterView = _footTableView;
    
}
- (void)loadBaseData
{
    
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{

   if(indexPath.section == 0)
   {
       if (indexPath.row == 0) {
           return  30.f;
       }else
           return 70.f;
       
   }else
   {
       if (indexPath.row == 0) {
           return  30.f;
       }else
           return 70.f;
 
   }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section == 0)
    {
        if (indexPath.row == 0) {
            return  _titleCellFirst;
        }else
            return  _contentCellFirst;
        
    }else
    {
        if (indexPath.row == 0) {
            return  _titleCellSecond;
        }else
            return _contentCellSecond;
        
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
/*
 
 选择律师
 */
- (IBAction)selectLawyer:(UIButton *)sender {
    DZShareNetApiClient *shareNetApiClient = [DZShareNetApiClient sharedClient];
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
    [self.navigationController.view addSubview:HUD];
    [HUD show:YES];
    NSString *URLString = [NSString stringWithFormat:@"index.php?/api/select_lawyer_to_case?user_id=%@case_id=%@&quotation_id=%@",_parameterData.user_id,_parameterData.case_id,_parameterData.quotation_id];
    
    URLString = [URLString stringByAddingPercentEscapesUsingEncoding: NSUTF8StringEncoding];
    
    [shareNetApiClient GET:URLString parameters:nil success:^(NSURLSessionDataTask *task, id JSON) {
        [shareNetApiClient.reachabilityManager stopMonitoring];
        NSLog(@"%@",[JSON objectForKey:@"code"]);
        
        if ([[JSON objectForKey:@"code"] integerValue] == 0) {
            [self showHUD:@"选择成功"];
        }else
            [self showHUD:@"选择失败"];
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        [shareNetApiClient.reachabilityManager stopMonitoring];
        if ([shareNetApiClient.reachabilityManager isReachable])
        {
            [self showHUD:@"网络无连接"];
        }else
            [self showHUD:@"选择失败"];
        
    }];

    
}

- (void)showHUD:(NSString *)message
{
    if (HUD) {
        [HUD hide:YES];
        HUD = nil;
    }
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.navigationController.view animated:YES];
    
    // Configure for text only and offset down
    hud.mode = MBProgressHUDModeText;
    hud.labelText = message;
    hud.margin = 10.f;
    hud.removeFromSuperViewOnHide = YES;
    
    [hud hide:YES afterDelay:3];
}
-(UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

@end
