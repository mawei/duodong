//
//  DZLawyerContentViewController.h
//  DaZhuang
//
//  Created by jason on 15/3/11.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import <UIKit/UIKit.h>
@class DZParameterData;
@interface DZLawyerContentViewController : UIViewController
@property (strong, nonatomic) IBOutlet UITableView *myTableView;
@property (strong, nonatomic) IBOutlet UITableViewCell *titleCellFirst;
@property (strong, nonatomic) IBOutlet UITableViewCell *titleCellSecond;
@property (strong, nonatomic) IBOutlet UITableViewCell *contentCellFirst;
@property (strong, nonatomic) IBOutlet UITableViewCell *contentCellSecond;
@property (strong, nonatomic) IBOutlet UIView *footTableView;

@property (nonatomic, strong)DZParameterData *parameterData;
- (IBAction)selectLawyer:(UIButton *)sender;

@end
