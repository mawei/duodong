//
//  DZSignViewController.h
//  DaZhuang
//
//  Created by Mac020 on 15/2/25.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DZSignViewController : UIViewController

@property (nonatomic, strong)NSString *roleTitle;


@property (weak, nonatomic) IBOutlet UITextField *fdMobile;//手机号
@property (weak, nonatomic) IBOutlet UITextField *fdPassword;//验证码



@property (weak, nonatomic) IBOutlet UILabel *btnPassword;
@property (weak, nonatomic) IBOutlet UIButton *btnLogin;

- (IBAction)selectBack:(id)sender;

- (IBAction)selectPassword:(UIButton *)sender;

- (IBAction)selectLogin:(UIButton *)sender;

- (IBAction)fdChaged:(UITextField *)sender;

@end
