//
//  DZEditNameViewController.h
//  DaZhuang
//
//  Created by jason on 15/3/15.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DZEditNameViewController : UIViewController
@property (strong, nonatomic) IBOutlet UITextField *fdName;
- (IBAction)fdChanged:(UITextField *)sender;

@end
