//
//  DZSelectRoleViewController.m
//  DaZhuang
//
//  Created by Mac020 on 15/2/25.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import "DZSelectRoleViewController.h"
#import "DZSignViewController.h"
#import "DZStatusManage.h"
#import "DZCustomNavigationController.h"
@interface DZSelectRoleViewController ()

@end

@implementation DZSelectRoleViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)selectRole:(UIButton *)sender {
    
    
    
    DZSignViewController *sign = [[DZSignViewController alloc] initWithNibName:@"DZSignViewController" bundle:nil];
    sign.roleTitle = sender.currentTitle;
    DZCustomNavigationController *nav = [[DZCustomNavigationController alloc] initWithRootViewController:sign];
    
    
    [self presentViewController:nav animated:YES completion:^{
        
        
    }];
}
-(UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

@end
