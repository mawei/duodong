//
//  DZSendLawyerImageViewController.m
//  DaZhuang
//
//  Created by Mac020 on 15/3/10.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import "DZSendLawyerImageViewController.h"
#import "DZShareNetApiClient.h"

@interface DZSendLawyerImageViewController ()<UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
     MBProgressHUD *HUD;
}
@property (nonatomic, assign)UIImageView *publiceImageView;

@end

@implementation DZSendLawyerImageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)chooseImgFirst:(UIButton *)sender {
    
    _publiceImageView = nil;
    _publiceImageView = _imgFirst;
    [self openMenu];
}

- (IBAction)chooseImageSecond:(UIButton *)sender {
    _publiceImageView = nil;
    _publiceImageView = _imgSecond;
    [self openMenu];
}

- (IBAction)sendImages:(UIButton *)sender {

    DZShareNetApiClient *shareNetApiClient = [DZShareNetApiClient sharedClient];
    
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    [HUD show:YES];
  NSString *URLString = [NSString stringWithFormat:@"index.php?/api/upload_lawyer_info"];
    NSDictionary *parameters = [NSDictionary dictionaryWithObjectsAndKeys:[DZStatusManage shareManage].roleUid,@"user_id", nil];
    URLString = [URLString stringByAddingPercentEscapesUsingEncoding: NSUTF8StringEncoding];
    [shareNetApiClient POST:URLString parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        
//        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
//        // 设置日期格式
//        formatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
//    
//        NSString *fileName = [formatter stringFromDate:[NSDate date]];
        [formData appendPartWithFileData:UIImageJPEGRepresentation(_imgFirst.image, 1.f) name:@"certificate_image" fileName:@"certificate_image.jpg" mimeType:@"image/jpeg"];
        
         [formData appendPartWithFileData:UIImageJPEGRepresentation(_imgFirst.image, 1.f) name:@"entrust_image" fileName:@"entrust_image.jpg" mimeType:@"image/jpeg"];
        
    } success:^(NSURLSessionDataTask *task, id responseObject) {
        [shareNetApiClient.reachabilityManager stopMonitoring];
        [[DZStatusManage shareManage] setRoleMessage:@"律师审核通过"];
        [self showMainViewController];
        [self showHUD:@"上传成功"];
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        [shareNetApiClient.reachabilityManager stopMonitoring];

        NSLog(@"%@",error);
        if ([shareNetApiClient.reachabilityManager isReachable])
        {
            [self showHUD:@"连接服务器失败"];
        }else
            [self showHUD:@"发送失败"];

    }];
    
    
}
- (void)showHUD:(NSString *)message
{
    if (HUD) {
        [HUD hide:YES];
        HUD = nil;
    }
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    // Configure for text only and offset down
    hud.mode = MBProgressHUDModeText;
    hud.labelText = message;
    hud.margin = 10.f;
    hud.removeFromSuperViewOnHide = YES;
    
    [hud hide:YES afterDelay:3];
}
- (void)showMainViewController
{
    [AppDelegateEntity showMainController];
    [self.navigationController willMoveToParentViewController:nil];
    [self.navigationController.view removeFromSuperview];
    [self.navigationController removeFromParentViewController];
    
}

/*
 
 打开相册和相机选择器
 */
- (void)openMenu
{
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"打开照相机",@"从手机相册获取", nil];
    
    [actionSheet showInView:self.view];
}

#pragma UIActionSheetDelegate

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex) {
        case 0:
            [self takePhoto];
            break;
        case 1:
            [self LocalPhoto];
            break;
        default:
            break;
    }
}

/*
 
 开始照相
 */
- (void)takePhoto
{
    
    if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera])
    {
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.delegate = self;
        //设置拍照后的图片可被编辑
        picker.allowsEditing = YES;
        picker.sourceType = UIImagePickerControllerSourceTypeCamera;
        [self presentViewController:picker animated:YES completion:nil];
    }else
    {
        NSLog(@"模拟其中无法打开照相机,请在真机中使用");
    }

    
}

/*
 打开本地相册
 */

- (void)LocalPhoto
{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    picker.delegate = self;
    //设置选择后的图片可被编辑
    picker.allowsEditing = YES;
    [self presentViewController:picker animated:YES completion:nil];

}

#pragma mark - UIImagePickerControllerDelegate

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    NSLog(@"您取消了选择图片");
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (void)imagePickerController:(UIImagePickerController*)picker didFinishPickingMediaWithInfo:(NSDictionary*)info
{
    UIImage* editedImage, *imageToSave;
    // Handle a still image capture
    editedImage = (UIImage*)[info objectForKey:UIImagePickerControllerOriginalImage];
    
    if (editedImage) {
        imageToSave = editedImage;
    }
    else {
        imageToSave = (UIImage*)[info objectForKey:UIImagePickerControllerOriginalImage];
    }
   
    //    imageViewPreview.image=imageToSave;
    //    self.imgSingleSelect=imageToSave;
    [picker dismissViewControllerAnimated:YES completion:^{
        if (picker.sourceType == UIImagePickerControllerSourceTypeCamera) {
            // Save the new image (original or edited) to the Camera Roll
            UIImageWriteToSavedPhotosAlbum(imageToSave, nil, nil, nil);
        }
        if (_publiceImageView) {
            NSData* imageScaleData = UIImageJPEGRepresentation(imageToSave, 1.0);
            if (imageScaleData.length > 500 * 1024) {
                imageScaleData = UIImageJPEGRepresentation(imageToSave, 0.5);
            }

            _publiceImageView.image = [UIImage imageWithData:imageScaleData];
        }
        
        if (_imgSecond.image && _imgFirst.image) {
            _btnSend.enabled = YES;
        }
    }];
    
    //camera下存储到图片库
  

}
-(UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}
@end
