//
//  DZTabBarController.m
//  DaZhuang
//
//  Created by Mac020 on 15/2/25.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import "DZTabBarController.h"
#import "DZStatusManage.h"
#import "DZLCenterViewController.h"
#import "DZLShowCaseViewController.h"
#import "DZVCenterViewController.h"
#import "DZVPutCaseViewController.h"
#import "DZCustomNavigationController.h"
@interface DZTabBarController ()

@end

@implementation DZTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self addChilds];
    // Do any additional setup after loading the view.
}

- (void)addChilds
{
    
    if ([[[DZStatusManage shareManage] roleTitle] isEqualToString:@"律师"]) {
//        DZLShowCaseViewController *caseViewController = [[DZLShowCaseViewController alloc] initWithNibName:@"DZLShowCaseViewController" bundle:nil];
//        DZCustomNavigationController *navLawyerCase = [[DZCustomNavigationController alloc] initWithRootViewController:caseViewController];
//        [self addOneChildVc:navLawyerCase title:@"案件" imageName:nil selectedImageName:nil];
        
        DZLCenterViewController *centerViewController = [[DZLCenterViewController alloc] initWithNibName:@"DZLCenterViewController" bundle:nil];
        DZCustomNavigationController *navLawyerCenter = [[DZCustomNavigationController alloc] initWithRootViewController:centerViewController];
//        self.tabBar.hidden = YES;
        [self addChildViewController:navLawyerCenter];
//        [self addOneChildVc:navLawyerCenter title:@"我的" imageName:nil
//          selectedImageName:nil];
        
        
        
    }else if ([[[DZStatusManage shareManage] roleTitle] isEqualToString:@"受害人"]){
        
        DZVPutCaseViewController *putCaseViewController = [[DZVPutCaseViewController alloc] initWithNibName:@"DZVPutCaseViewController" bundle:nil];
        DZCustomNavigationController *navPutCase = [[DZCustomNavigationController alloc] initWithRootViewController:putCaseViewController];
        [self addOneChildVc:navPutCase title:@"上传案件" imageName:nil
          selectedImageName:nil];
        
        DZVCenterViewController *centerViewController = [[DZVCenterViewController alloc] initWithNibName:@"DZVCenterViewController" bundle:nil];
        DZCustomNavigationController *navCenter = [[DZCustomNavigationController alloc] initWithRootViewController:centerViewController];

        [self addOneChildVc:navCenter title:@"我的" imageName:nil selectedImageName:nil];
        
        
        
    }
    
}

-(void)addOneChildVc:(UIViewController *)childVc title:(NSString *)title imageName:(NSString *)imageName selectedImageName:(NSString *)selectedImageName{
    
    childVc.title = title;
    //设置图标
    childVc.tabBarItem.image = [UIImage imageNamed:imageName];
    //设置选中时的图标
    UIImage * selectedImage = [UIImage imageNamed:selectedImageName];
    if (iOS7) {
        //不渲染原图
        selectedImage = [selectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    }
    childVc.tabBarItem.selectedImage = selectedImage;
    
    [self addChildViewController:childVc];

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
