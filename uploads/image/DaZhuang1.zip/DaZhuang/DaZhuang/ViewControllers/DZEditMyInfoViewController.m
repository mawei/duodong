//
//  DZEditMyInfoViewController.m
//  DaZhuang
//
//  Created by jason on 15/3/14.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import "DZEditMyInfoViewController.h"
#import "DZEditNameViewController.h"
#import "DZStatusManage.h"
@interface DZEditMyInfoViewController ()<UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>


@end

@implementation DZEditMyInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self loadBaseView];
    [self loadBaseData];

    // Do any additional setup after loading the view from its nib.
}
- (void)loadBaseView
{
    self.navigationItem.title = @"个人信息";
    self.myTableView.tableHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _myTableView.frame.size.width, 20.f)];
}

- (void)loadBaseData
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docspath = [paths objectAtIndex:0];
    NSString *headName = [docspath stringByAppendingPathComponent:@"headImage.jpg"];
    NSFileManager *fileMgr = [NSFileManager defaultManager];
    if ([fileMgr fileExistsAtPath:headName]) {
        _imgHead.image = [UIImage imageWithContentsOfFile:headName];
    }
  
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{

    switch (indexPath.row) {
        case 0:
           return  _headCell.frame.size.height;
            break;
        case 1:
            return  _nameCell.frame.size.height;
            break;

        default:
            break;
    }
    return 0;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
        switch (indexPath.row) {
            case 0:
                return _headCell;
                break;
            case 1:
                return _nameCell;
                break;
            default:
                break;
        }

    return nil;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
        [_myTableView deselectRowAtIndexPath:indexPath animated:YES];
        [self openMenu];
    }else if(indexPath.row == 1){
        
        DZEditNameViewController *editNameViewController = [[DZEditNameViewController alloc] initWithNibName:@"DZEditNameViewController" bundle:nil];
        [self.navigationController pushViewController:editNameViewController animated:YES];
    }
    return;

    
}

/*
 
 打开相册和相机选择器
 */
- (void)openMenu
{
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"打开照相机",@"从手机相册获取", nil];
    
    [actionSheet showInView:self.view];
}

#pragma UIActionSheetDelegate

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex) {
        case 0:
            [self takePhoto];
            break;
        case 1:
            [self LocalPhoto];
            break;
        default:
            break;
    }
}
/*
 
 开始照相
 */
- (void)takePhoto
{
    
    if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera])
    {
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.delegate = self;
        //设置拍照后的图片可被编辑
        picker.allowsEditing = YES;
        picker.sourceType = UIImagePickerControllerSourceTypeCamera;
        [self presentViewController:picker animated:YES completion:nil];
    }else
    {
        NSLog(@"模拟其中无法打开照相机,请在真机中使用");
    }
    
    
}

/*
 打开本地相册
 */

- (void)LocalPhoto
{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    picker.delegate = self;
    //设置选择后的图片可被编辑
    picker.allowsEditing = YES;
    [self presentViewController:picker animated:YES completion:nil];
    
}
#pragma mark - UIImagePickerControllerDelegate

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    NSLog(@"您取消了选择图片");
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (void)imagePickerController:(UIImagePickerController*)picker didFinishPickingMediaWithInfo:(NSDictionary*)info
{
    UIImage* editedImage, *imageToSave;
    // Handle a still image capture
    editedImage = (UIImage*)[info objectForKey:UIImagePickerControllerOriginalImage];
    
    if (editedImage) {
        imageToSave = editedImage;
    }
    else {
        imageToSave = (UIImage*)[info objectForKey:UIImagePickerControllerOriginalImage];
    }
    
    //    imageViewPreview.image=imageToSave;
    //    self.imgSingleSelect=imageToSave;
    [picker dismissViewControllerAnimated:YES completion:^{
        if (picker.sourceType == UIImagePickerControllerSourceTypeCamera) {
            // Save the new image (original or edited) to the Camera Roll
            UIImageWriteToSavedPhotosAlbum(imageToSave, nil, nil, nil);
        }
        if (_imgHead) {
            NSData* imageScaleData = UIImageJPEGRepresentation(imageToSave, 1.0);
            if (imageScaleData.length > 500 * 1024) {
                imageScaleData = UIImageJPEGRepresentation(imageToSave, 0.5);
            }
            NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
            NSString *docspath = [paths objectAtIndex:0];
            NSString *headName = [docspath stringByAppendingPathComponent:@"headImage.jpg"];
            [imageScaleData writeToFile:headName atomically:YES];
            _imgHead.image = [UIImage imageWithData:imageScaleData];
        }
        
        
    }];
    
    //camera下存储到图片库
    
    
}
-(UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [_myTableView deselectRowAtIndexPath:[_myTableView indexPathForSelectedRow] animated:YES];
    if(![[DZStatusManage shareManage].roleName isEqualToString:@"还没有昵称"])
    _lbName.text = [DZStatusManage shareManage].roleName;

}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
