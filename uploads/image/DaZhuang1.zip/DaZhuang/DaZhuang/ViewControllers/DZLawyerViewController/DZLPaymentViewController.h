//
//  DZLPaymentViewController.h
//  DaZhuang
//
//  Created by jason on 15/3/21.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DZLPaymentViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITableView *myTableView;

@end
