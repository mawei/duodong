//
//  DZLShowCaseViewController.m
//  DaZhuang
//
//  Created by Mac020 on 15/2/25.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import "DZLShowCaseViewController.h"

@interface DZLShowCaseViewController ()

@end

@implementation DZLShowCaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self loadBaseView];
    [self loadBaseData];
    // Do any additional setup after loading the view from its nib.
}
- (void)loadBaseView
{
    self.navigationItem.title = @"案件展示";
}

- (void)loadBaseData
{
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
