//
//  DZLCenterViewController.h
//  DaZhuang
//
//  Created by Mac020 on 15/2/25.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DZLCenterViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITableView *myTableView;
@property (strong, nonatomic) IBOutlet UITableViewCell *myUserCell;
@property (strong, nonatomic) IBOutlet UITableViewCell *myPayCell;
@property (strong, nonatomic) IBOutlet UITableViewCell *myOverCell;
@property (strong, nonatomic) IBOutlet UITableViewCell *myOrderCell;
@property (strong, nonatomic) IBOutlet UITableViewCell *myNotificationCell;

@property (weak, nonatomic) IBOutlet UIImageView *imgHead;
@property (weak, nonatomic) IBOutlet UILabel *lbName;
@property (weak, nonatomic) IBOutlet UILabel *lbRole;
@property (weak, nonatomic) IBOutlet UILabel *lbRoleMobile;


@end
