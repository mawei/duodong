//
//  DZEditNameViewController.m
//  DaZhuang
//
//  Created by jason on 15/3/15.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import "DZEditNameViewController.h"
#import "DZStatusManage.h"
@interface DZEditNameViewController ()
@property (nonatomic, strong)UIBarButtonItem *rightBarButton;
@end

@implementation DZEditNameViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"设置昵称";
    _rightBarButton = [[UIBarButtonItem alloc] initWithTitle:@"保存" style:UIBarButtonItemStylePlain target:self action:@selector(selectSave:)];
    self.navigationItem.rightBarButtonItem = _rightBarButton;
    _rightBarButton.enabled = NO;
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (void)selectSave:(id)sender {
    
    [DZStatusManage shareManage].roleName = _fdName.text;
    [self.navigationController popViewControllerAnimated:YES];
    
}

- (IBAction)fdChanged:(UITextField *)sender {
    
    BOOL isStringtoSpace=YES;//是否是空格
    NSString *strSpace =@" ";
    for(int i =0;i<[sender.text  length];i++)    {
        NSString *string = [sender.text substringWithRange:NSMakeRange(i, 1)];//抽取子字符
        if(![string isEqualToString:strSpace]){//判断是否为空格
            isStringtoSpace=NO; //如果是则改变 状态
            break;//结束循环
        }
    }
    if (isStringtoSpace) {
        _rightBarButton.enabled = NO;
    }else
        _rightBarButton.enabled = YES;
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [_fdName becomeFirstResponder];

}
@end
