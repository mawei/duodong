//
//  DZSendLawyerImageViewController.h
//  DaZhuang
//
//  Created by Mac020 on 15/3/10.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DZSendLawyerImageViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *imgFirst;
@property (weak, nonatomic) IBOutlet UIImageView *imgSecond;
- (IBAction)chooseImgFirst:(UIButton *)sender;
- (IBAction)chooseImageSecond:(UIButton *)sender;
- (IBAction)sendImages:(UIButton *)sender;
@property (weak, nonatomic) IBOutlet UIButton *btnSend;

@end
