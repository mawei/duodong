//
//  DZSignViewController.m
//  DaZhuang
//
//  Created by Mac020 on 15/2/25.
//  Copyright (c) 2015年 sxq09876. All rights reserved.
//

#import "DZSignViewController.h"
#import "DZShareNetApiClient.h"
#import <SMS_SDK/SMS_SDK.h>

@interface DZSignViewController ()<UITextFieldDelegate>
{
    BOOL isPassword;
    BOOL isLogin;
    BOOL isTimer;
    MBProgressHUD *HUD;
}
@property (nonatomic, strong)NSTimer *passwordTimer;
@property (nonatomic, assign)NSUInteger numberTimer;
@property (nonatomic, strong)NSMutableArray *areaArray;
@end
@implementation DZSignViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self configBaseView];
    [self loadBaseData];
    // Do any additional setup after loading the view from its nib.
}

- (void)configBaseView
{
//    float ver =[[[UIDevice currentDevice] systemVersion] floatValue];
//    if(ver>=7.0)
//    {
//        self.edgesForExtendedLayout =UIRectEdgeNone;
//      
//    }
//      UIColor * color = [UIColor whiteColor];
//      NSDictionary * dict=[NSDictionary dictionaryWithObject:color forKey:NSForegroundColorAttributeName];
//     self.navigationController.navigationBar.titleTextAttributes = dict;
    self.navigationItem.title = @"登录";
    UIImage* image = [UIImage imageNamed:@"arrow_back"];
    UIButton *btnBack = [UIButton buttonWithType:UIButtonTypeCustom];
    btnBack.frame = CGRectMake(0, 0, self.navigationController.navigationBar.bounds.size.height, self.navigationController.navigationBar.bounds.size.height);
    btnBack.contentEdgeInsets = UIEdgeInsetsMake(0, -10, 0, 10);
    [btnBack setImage:image forState:UIControlStateNormal];
    [btnBack addTarget:self action:@selector(selectBack:) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:btnBack];

}

- (void)loadBaseData
{
    _areaArray= [NSMutableArray array];

    [SMS_SDK getZone:^(enum SMS_ResponseState state, NSArray *array)
     {
         if (1==state)
         {
             NSLog(@"sucessfully get the area code");
             //区号数据
             _areaArray=[NSMutableArray arrayWithArray:array];
         }
         else if (0==state)
         {
             NSLog(@"failed to get the area code");
         }
         
     }];

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)selectBack:(id)sender {
    
    [_fdPassword resignFirstResponder];
    [_fdMobile resignFirstResponder];
    [self.navigationController dismissViewControllerAnimated:YES completion:^{
        if (_passwordTimer) {
            [_passwordTimer invalidate];
            _passwordTimer = nil;
        };
    }];
}
/*
 获取验证码 60s一次
 
 */
- (IBAction)selectPassword:(UIButton *)sender {
    if (![self sendSMSTest]) {
        
        return;
    };
    isPassword = NO;
    isTimer = YES;
    _numberTimer = 60;
    [self changeBtnState];
      NSString * title = [NSString stringWithFormat:@"%d秒后重发",_numberTimer];
    [_btnPassword setText:title];

    if (!_passwordTimer) {
        _passwordTimer = [NSTimer scheduledTimerWithTimeInterval:1.f target:self selector:@selector(refreshBtn) userInfo:nil repeats:YES];
    }
    
    
}

/*
 
 发送短信验证码
 
 */
- (BOOL)sendSMSTest
{
    for (int i=0; i<_areaArray.count; i++)
    {
        NSDictionary* dict1=[_areaArray objectAtIndex:i];
        NSString* code1 = [dict1 valueForKey:@"zone"];
        if ([code1 isEqualToString:@"86"]) {
            NSString* rule1=[dict1 valueForKey:@"rule"];
            NSPredicate* pred=[NSPredicate predicateWithFormat:@"SELF MATCHES %@",rule1];
            BOOL isMatch=[pred evaluateWithObject:self.fdMobile.text];
            if (!isMatch)
            {
                //手机号码不正确
                UIAlertView* alert=[[UIAlertView alloc] initWithTitle:NSLocalizedString(@"notice", nil)
                                                              message:NSLocalizedString(@"errorphonenumber", nil)
                                                             delegate:self
                                                    cancelButtonTitle:NSLocalizedString(@"sure", nil)
                                                    otherButtonTitles:nil, nil];
                [alert show];
                return NO;
            }
            break;
        }
    }
    [SMS_SDK getVerificationCodeBySMSWithPhone:self.fdMobile.text
                                                zone:@"86"
                                              result:^(SMS_SDKError *error)
     {
         
         if (!error)
         {
             
          }
         else
         {
             UIAlertView* alert=[[UIAlertView alloc] initWithTitle:NSLocalizedString(@"codesenderrtitle", nil)
                                                           message:[NSString stringWithFormat:@"状态码：%zi ,错误描述：%@",error.errorCode,error.errorDescription]
                                                          delegate:self
                                                 cancelButtonTitle:NSLocalizedString(@"sure", nil)
                                                 otherButtonTitles:nil, nil];
             [alert show];
         }
         
     }];

    return YES;
    
}
- (void)refreshBtn
{
    _numberTimer --;
    NSString * title = [NSString stringWithFormat:@"%d秒后重发",_numberTimer];
    
    [_btnPassword setText:title];
    if (_numberTimer == 0) {
        if (_passwordTimer) {
            [_passwordTimer invalidate];
            _passwordTimer = nil;
            NSString * title = @"获取验证码";
            [_btnPassword setText:title];
            isTimer = NO;
           if(_fdMobile.text.length == 11)
            isPassword = YES;
            else
            isPassword = NO;
            
            if (_fdPassword.text.length == 4) {
                  if(_fdMobile.text.length == 11)
                isLogin = YES;
                else
                    isLogin = NO;
            }else
                isLogin = NO;
            [self changeBtnState];
        }
    }
    
}

- (IBAction)selectLogin:(UIButton *)sender {
    [DZStatusManage shareManage].roleTitle = _roleTitle;
    
    [SMS_SDK commitVerifyCode:self.fdPassword.text result:^(enum SMS_ResponseState state) {
        if (1==state)
        {
            NSLog(@"验证成功");
            [self loginTask];
        }
        else if(0==state)
        {
            NSLog(@"验证失败");
            NSString* str=[NSString stringWithFormat:NSLocalizedString(@"verifycodeerrormsg", nil)];
            UIAlertView* alert=[[UIAlertView alloc] initWithTitle:NSLocalizedString(@"verifycodeerrortitle", nil)
                                                          message:str
                                                         delegate:self
                                                cancelButtonTitle:NSLocalizedString(@"sure", nil)
                                                otherButtonTitles:nil, nil];
            [alert show];
        }
    }];

}

- (void)loginTask
{
    DZShareNetApiClient *shareNetApiClient = [DZShareNetApiClient sharedClient];
    
       HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
       [self.navigationController.view addSubview:HUD];
       [HUD show:YES];

    NSString *URLString = [NSString stringWithFormat:@"index.php?/api/login?username=%@&type=%@",_fdMobile.text,_roleTitle];
    
    URLString = [URLString stringByAddingPercentEscapesUsingEncoding: NSUTF8StringEncoding];
    
    [shareNetApiClient GET:URLString parameters:nil success:^(NSURLSessionDataTask *task, id JSON) {
        [shareNetApiClient.reachabilityManager stopMonitoring];
        NSLog(@"%@",[JSON objectForKey:@"code"]);

        if ([[JSON objectForKey:@"code"] integerValue] == 0) {
            NSString *uid = [JSON objectForKey:@"data"];
            [DZStatusManage shareManage].roleUid= uid;
            [DZStatusManage shareManage].roleMobile = _fdMobile.text;
            [self showMainViewController];
            
        }else
            [self showHUD:@"登陆失败"];
      
    } failure:^(NSURLSessionDataTask *task, NSError *error) {

        if ([shareNetApiClient.reachabilityManager isReachable])
        {
            [self showHUD:@"网络无连接"];
        }else
        [self showHUD:@"登陆失败"];
        
        [shareNetApiClient.reachabilityManager stopMonitoring];

    }];
    
}

- (void)showMainViewController
{
    [AppDelegateEntity showMainController];
    [self.navigationController willMoveToParentViewController:nil];
    [self.navigationController.view removeFromSuperview];
    [self.navigationController removeFromParentViewController];

}


- (void)showHUD:(NSString *)message
{
    if (HUD) {
        [HUD hide:YES];
        HUD = nil;
    }
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.navigationController.view animated:YES];
    
    // Configure for text only and offset down
    hud.mode = MBProgressHUDModeText;
    hud.labelText = message;
    hud.margin = 10.f;
    hud.removeFromSuperViewOnHide = YES;
    
    [hud hide:YES afterDelay:3];
}
- (IBAction)fdChaged:(UITextField *)sender {
    
    
    if (sender == _fdMobile) {
        if (sender.text.length <= 11) {
            if (sender.text.length == 11) {
                if (isTimer) {
                    isPassword = NO;
                }else{
                    isPassword = YES;
                }
                if (_fdPassword.text.length == 4) {
                    isLogin = YES;
                }else
                    isLogin = NO;
            }
            else{
                isPassword = NO;
                isLogin = NO;
            }
            [self changeBtnState];
        }else
            return;
    }else if (sender == _fdPassword){
        
        if (sender.text.length <= 4) {
            if (sender.text.length == 4) {
                if (_fdMobile.text.length == 11) {
                    isLogin = YES;
                }else
                    isLogin = NO;
                
            }else{
                isLogin = NO;
            }
            
            [self changeBtnState];
            
        }else
            return;
    }

    
    
}

- (void)changeBtnState
{
    
  
    if (isPassword) {
         _btnPassword.enabled = YES;
        [_btnPassword setBackgroundColor:[UIColor colorWithRed:243.f/255.f green:169.f/255.f blue:24.f/255.f alpha:1.f]];
        
    }else
    {
        _btnPassword.enabled = NO;
        [_btnPassword setBackgroundColor:[UIColor colorWithRed:170.f/255.f green:170.f/255.f blue:170.f/255.f alpha:1.f]];
    }
    if (isLogin) {
        _btnLogin.enabled = YES;
        [_btnLogin setBackgroundColor:[UIColor colorWithRed:243.f/255.f green:169.f/255.f blue:24.f/255.f alpha:1.f]];
        
    }else{
        _btnLogin.enabled = NO;
        [_btnLogin setBackgroundColor:[UIColor colorWithRed:170.f/255.f green:170.f/255.f blue:170.f/255.f alpha:1.f]];
    }

}

#pragma UITextFieldDelegate

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    if (textField == _fdMobile) {
        if (range.location <= 10) {
           return YES;
        }else
            return NO;
    }else if (textField == _fdPassword){
        
        if (range.location <= 3) {
        return YES;

        }
    }
    return NO;
}
-(UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

@end
